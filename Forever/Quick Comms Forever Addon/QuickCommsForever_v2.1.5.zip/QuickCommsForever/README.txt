Quick Comms Forever v2.1.0 — redesigned radial wheel

- Eight wedge-shaped slots with gold borders and blue hover highlight.
- Click any wedge to send its saved saying; wheel remains open.
- Wheel reads the exact same saved sayings as List View (eight per page).
- Click Chat in the hub to cycle AUTO / RAID / PARTY / SAY / YELL.
- Drag the hub title to move the wheel; scale from /qcf options.
- Minimize with the small - at upper right; use + on QCF mini box to restore.
- Switch to List View using the button beneath the wheel.
- Wheel hotkey can be assigned in Key Bindings.

Install the QuickCommsForever folder in Interface/AddOns.
Interface 16001. This build has not been tested in the WoW Forever client.

v1.9.6: Wheel now reads the exact same saved messages as List View, in the same order. Previous manual wheel slot overrides are retired. Eight messages per page; use < and > below the wheel to navigate all saved sayings.

Version 1.9.5: Clicking a wheel saying sends immediately and leaves the wheel open. Minimize, List View, hotkey toggle, and explicit wheel-off still hide it.

Version 1.9.2: Main list uses one shared Chat channel selector (AUTO/RAID/PARTY/SAY/YELL). Click a saying to send instantly. P/S/Y buttons removed. Unlock Order mode disables sending and shows reorder/delete controls. Wheel and list share channel.

Quick Comms Forever v1.8.1

Wheel channel button: click Chat: AUTO in the wheel hub to cycle AUTO -> RAID -> PARTY -> SAY -> YELL -> AUTO. The chosen channel is saved, and all wheel sayings use it. AUTO uses raid if raiding, otherwise party if grouped. SAY and YELL work without a group. Channel also selectable from Options or /qcf channel auto|raid|party|say|yell.

Quick Comms Forever 1.3.0 — WoW Forever (Interface 16001)

New in 1.3.0:
- Removed the X buttons beside P/S/Y to prevent accidental deletion.
- Resize the list window by dragging the bottom-right corner; size is saved.
- Radial wheel now has an eight-segment circular appearance with a transparent exterior.
- To delete a saying intentionally, use /qcf remove NUMBER and then /qcf confirm. /qcf cancel aborts.

Commands: /qcf, /qcf wheel, /qcf wheel on/off, /qcf channel auto/party/raid,
/qcf slot SLOT MESSAGE_NUMBER, /qcf remove NUMBER, /qcf confirm, /qcf cancel.

Assign the wheel key in Key Bindings. Press the key to show the wheel, click a slice to send.
Key-release sending is not supported by this build.

Install QuickCommsForever under Interface/AddOns. Restart or /reload.
WoW Forever in-game behavior has not been verified.

Version 1.4.0:
- Click the _ button beside the window close button to minimize the list to a movable QCF box.
- Click + on the QCF box to expand the list again.
- /qcf minimize and /qcf expand are also supported.
- /qcf toggles between the full list and minimized box; /qcf hide hides both.
- Minimized state and mini-box position are saved across sessions.
- The radial wheel remains independent and only appears when activated.

Version 1.4.2: Increased spacing between minimize and close buttons to 35 pixels to prevent accidental closing.

Startup: The expanded list opens automatically on login unless minimized, in which case the QCF mini box appears.

Version 1.5.1: Locked by default. Unlock Order replaces P/S/Y with reorder arrows; Lock Order restores P/S/Y and hides arrows. Commands: /qcf lock, /qcf unlock.

VERSION 1.6.0
- Options buttons on the main list and radial wheel. /qcf options also opens settings.
- Enable/disable wheel, show list at login, lock/unlock message order.
- Cycle wheel channel AUTO/PARTY/RAID.
- Resize radial wheel 60%-160% with +/- controls; drag its center to reposition.
- Wheel position and scale persist across sessions; Center Wheel resets its location.

Version 1.7.0 changes:
- Unlock Order shows Delete controls; deletion requires a confirmation dialog.
- The radial wheel automatically shows the first eight saved sayings in current list order.
- Manual /qcf slot assignments override automatic wheel positions.
- Wheel Close button moved to central hub below Click to send.
- Wheel Options button removed; use list Options or /qcf options.

Version 1.8.1: The wheel center Close control is now Minimize. Clicking it hides the wheel while preserving its hotkey, channel, scale, and position. Reopen with the wheel keybind or /qcf wheel.

Version 1.9.2: List header Close button removed; Hide List button removed; Unlock Order button moved exclusively to Options > Lock saved saying positions. Uncheck to reorder/delete, check to send. Minimize remains available.

Version 1.9.2: Switch between List View and Wheel View using the List button and wheel hub List View button. Opening either view hides the other. The wheel retains its Minimize button.

Version 1.9.5: Wheel chat selector moved below center; minimize changed to small top-right minus; List View button moved below the wheel.

Version 1.9.5: Minimizing the wheel now displays the same movable QCF mini box used by List View. The + button restores the view that was minimized.

2.1.0: Refreshed list styling, alternating message row panels, gold header divider, responsive anchored new-entry field and Add button.

Version 2.1.5: List and Options header notes are anchored to both window edges and wrap automatically at the available width. Layout spacing adjusted to avoid overlapping controls.

AUTO chat channel: RAID if in a raid, PARTY if in a party, otherwise SAY.

Version 2.1.5: AUTO prioritizes RAID > PARTY > SAY; YELL is manual. Group checks support modern and legacy APIs.
