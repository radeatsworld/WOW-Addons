-- Quick Comms Forever 2.1.5 | WoW Forever (Interface 16001)
local addonName = ...
local db, list, wheel, mini, optionsPanel
local refreshOptions, applyWheelScale
local rows, wheelButtons = {}, {}
local refresh, updateWheel
local lockButton, helpText, wheelChannelButton, listChannelButton, wheelPageLabel
local deleteMessage
local function saveMiniPosition()
    if not db or not mini then return end
    local x,y=mini:GetCenter()
    local ux,uy=UIParent:GetCenter()
    if x and y and ux and uy then
        db.miniX=x-ux; db.miniY=y-uy
    end
end
local function minimizeList()
    if not db or not list or not mini then return end
    db.listMinimized=true
    db.minimizedView="list"
    list:Hide()
    mini:Show()
    if wheel then wheel:Hide() end
end
local function expandList()
    if not db or not list or not mini then return end
    db.listMinimized=false
    db.minimizedView="list"
    mini:Hide()
    list:Show()
    if wheel then wheel:Hide() end
end
BINDING_HEADER_QUICKCOMMSFOREVER = "Quick Comms Forever"
BINDING_NAME_QUICKCOMMSFOREVERWHEEL = "Toggle Quick Comms Wheel"

local function notice(message)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cff73aeffQuick Comms:|r " .. tostring(message)) end
end
-- AUTO priority: RAID > PARTY > SAY. YELL remains a manual channel.
-- Support both modern group APIs and older group-count APIs.
local function groupChannel()
    local inRaid = (type(IsInRaid) == "function" and IsInRaid())
        or (type(GetNumRaidMembers) == "function" and GetNumRaidMembers() > 0)
    if inRaid then return "RAID" end
    local inParty = (type(IsInGroup) == "function" and IsInGroup())
        or (type(GetNumPartyMembers) == "function" and GetNumPartyMembers() > 0)
    if inParty then return "PARTY" end
    return "SAY"
end
local function send(message, channel)
    if type(message) ~= "string" or message == "" then return end
    if channel == "AUTO" then channel = groupChannel() end
    if not channel then channel = "SAY" end
    if channel == "RAID" and groupChannel() ~= "RAID" then notice("You are not in a raid."); return end
    if channel == "PARTY" and groupChannel() == "SAY" then notice("You are not in a group."); return end
    if SendChatMessage then SendChatMessage(message, channel) end
end
local function makeFrame(name, width, height)
    local f = CreateFrame("Frame", name, UIParent, "BackdropTemplate")
    f:SetSize(width, height)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border", tile=true, tileSize=32, edgeSize=32, insets={left=11,right=12,top=12,bottom=11}})
    f:Hide()
    return f
end
local function button(parent, label, width, height, callback)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, height)
    b:SetText(label)
    b:SetScript("OnClick", callback)
    return b
end
local function closeWheel() if wheel then wheel:Hide() end end
local function minimizeWheel()
    if not db or not wheel or not mini then return end
    db.listMinimized=true
    db.minimizedView="wheel"
    wheel:Hide()
    if list then list:Hide() end
    mini:Show()
end
local function expandMinimized()
    if not db then return end
    if db.minimizedView=="wheel" and db.wheelEnabled and wheel then
        db.listMinimized=false
        mini:Hide()
        if list then list:Hide() end
        wheel:Show()
    else
        expandList()
    end
end
local CHANNEL_ORDER = {"AUTO", "RAID", "PARTY", "SAY", "YELL"}
local function cycleWheelChannel()
    if not db then return end
    local current = db.wheelChannel or "AUTO"
    local nextChannel = CHANNEL_ORDER[1]
    for i=1,#CHANNEL_ORDER do
        if CHANNEL_ORDER[i] == current then
            nextChannel = CHANNEL_ORDER[(i % #CHANNEL_ORDER)+1]
            break
        end
    end
    db.wheelChannel = nextChannel
    if wheelChannelButton then wheelChannelButton:SetText("Chat: " .. nextChannel) end
    if listChannelButton then listChannelButton:SetText("Chat: " .. nextChannel) end
    if refreshOptions and optionsPanel then refreshOptions() end
end
local function wheelSend(index)
    local messageIndex = ((db.wheelPage or 1)-1)*8 + index
    if messageIndex == nil then messageIndex = index end
    if messageIndex and db.messages[messageIndex] then
        send(db.messages[messageIndex], db.wheelChannel or "AUTO")
    else
        notice("No saved saying in this wheel position.")
    end
    -- Keep the wheel visible after sending; only explicit minimize/view actions hide it.
end
local function saveWheelPosition()
    if not wheel or not db then return end
    local x,y=wheel:GetCenter()
    local ux,uy=UIParent:GetCenter()
    local scale=wheel:GetEffectiveScale()/UIParent:GetEffectiveScale()
    if x and y and ux and uy and scale>0 then
        db.wheelX=(x-ux)/scale
        db.wheelY=(y-uy)/scale
    end
end
applyWheelScale=function()
    if not wheel or not db then return end
    wheel:SetScale(db.wheelScale or 1)
    wheel:ClearAllPoints()
    wheel:SetPoint("CENTER",UIParent,"CENTER",db.wheelX or 0,db.wheelY or 0)
end
local function toggleOptions()
    if not optionsPanel then return end
    if optionsPanel:IsShown() then optionsPanel:Hide() else refreshOptions();optionsPanel:Show() end
end
local wheelHover = 0
local wheelHoverArt
local function wheelHitTest()
    if not wheel then return nil end
    local cx,cy=wheel:GetCenter()
    local x,y=GetCursorPosition()
    local scale=wheel:GetEffectiveScale()
    if not cx or not cy or not scale or scale==0 then return nil end
    local dx=x/scale-cx
    local dy=y/scale-cy
    local radius=math.sqrt(dx*dx+dy*dy)
    -- Art's visible wedge ring spans about 89 to 198 frame units.
    if radius < 90 or radius > 197 then return nil end
    local angle
    if math.atan2 then angle=math.deg(math.atan2(dy,dx))
    elseif dx==0 then angle=dy>=0 and 90 or -90
    else
        angle=math.deg(math.atan(dy/dx))
        if dx<0 then angle=angle+180 end
    end
    local index=(math.floor(((90-angle+22.5)%360)/45)+1)
    return index
end
local function wheelHoverUpdate()
    local index=wheelHitTest()
    if wheelHover == index then return end
    wheelHover=index
    if wheelHoverArt then
        if index then
            wheelHoverArt:SetTexture("Interface\\AddOns\\QuickCommsForever\\WheelHighlight"..index..".tga")
            wheelHoverArt:Show()
        else wheelHoverArt:Hide() end
    end
    for i=1,8 do
        if wheelButtons[i] and wheelButtons[i].label then
            if i==index then wheelButtons[i].label:SetTextColor(1,0.84,0.48)
            else wheelButtons[i].label:SetTextColor(0.96,0.92,0.84) end
        end
    end
end
local function makeWheel()
    wheel=CreateFrame("Frame","QuickCommsForeverWheel",UIParent)
    wheel:SetSize(440,440); wheel:SetPoint("CENTER"); wheel:SetFrameStrata("DIALOG")
    wheel:SetMovable(true); wheel:SetClampedToScreen(true); wheel:EnableMouse(true)
    local art=wheel:CreateTexture(nil,"BACKGROUND")
    art:SetAllPoints(wheel)
    art:SetTexture("Interface\\AddOns\\QuickCommsForever\\Wheel.tga")
    wheelHoverArt=wheel:CreateTexture(nil,"ARTWORK")
    wheelHoverArt:SetAllPoints(wheel);wheelHoverArt:Hide()
    -- One circular hit test instead of eight overlapping rectangular buttons.
    wheel:SetScript("OnUpdate",wheelHoverUpdate)
    wheel:SetScript("OnMouseUp",function(self,mouseButton)
        if mouseButton~="LeftButton" then return end
        local index=wheelHitTest()
        if index then wheelSend(index) end
    end)
    for i=1,8 do
        local angle=math.rad(90-(i-1)*45)
        local x,y=math.cos(angle)*145,math.sin(angle)*145
        local label=wheel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        label:SetSize(105,65)
        label:SetPoint("CENTER",wheel,"CENTER",x,y)
        label:SetJustifyH("CENTER");label:SetJustifyV("MIDDLE")
        label:SetTextColor(0.96,0.92,0.84)
        wheelButtons[i]={label=label}
    end
    local center=wheel:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    center:SetPoint("CENTER",0,34);center:SetText("Quick Comms")
    local subtitle=wheel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    subtitle:SetPoint("CENTER",0,10);subtitle:SetText("Click to send")
    -- Only the hub's upper part is draggable; it does not cover the channel selector.
    local drag=CreateFrame("Button",nil,wheel)
    drag:SetSize(132,46);drag:SetPoint("CENTER",0,30)
    drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart",function() wheel:StartMoving() end)
    drag:SetScript("OnDragStop",function() wheel:StopMovingOrSizing();saveWheelPosition() end)
    drag:SetScript("OnEnter",function(self) GameTooltip:SetOwner(self,"ANCHOR_TOP");GameTooltip:SetText("Drag to move the wheel");GameTooltip:Show() end)
    drag:SetScript("OnLeave",function() GameTooltip:Hide() end)
    wheelChannelButton=button(wheel,"Chat: AUTO",135,24,cycleWheelChannel)
    wheelChannelButton:SetPoint("CENTER",wheel,"CENTER",0,-31)
    wheelChannelButton:SetScript("OnEnter",function(self)
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:SetText("Click to cycle: Auto, Raid, Party, Say, Yell")
        GameTooltip:Show()
    end)
    wheelChannelButton:SetScript("OnLeave",function() GameTooltip:Hide() end)
    local minimize=button(wheel,"-",25,23,minimizeWheel)
    minimize:SetPoint("CENTER",wheel,"CENTER",209,209)
    local toList=button(wheel,"List View",112,24,function() closeWheel();expandList() end)
    toList:SetPoint("CENTER",wheel,"CENTER",0,-251)
    local prev=button(wheel,"<",28,22,function()
        db.wheelPage=math.max(1,(db.wheelPage or 1)-1);updateWheel()
    end)
    prev:SetPoint("CENTER",wheel,"CENTER",-68,-219)
    wheelPageLabel=wheel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    wheelPageLabel:SetPoint("CENTER",wheel,"CENTER",0,-219)
    local nextPage=button(wheel,">",28,22,function()
        local maxPage=math.max(1,math.ceil(#db.messages/8))
        db.wheelPage=math.min(maxPage,(db.wheelPage or 1)+1);updateWheel()
    end)
    nextPage:SetPoint("CENTER",wheel,"CENTER",68,-219)
    wheel:SetScript("OnShow",function() wheelHover=0;updateWheel() end)
    applyWheelScale()
    wheel:Hide()
end
updateWheel=function()
    if not db then return end
    if wheelChannelButton then wheelChannelButton:SetText("Chat: " .. (db.wheelChannel or "AUTO")) end
    local maxPage=math.max(1,math.ceil(#db.messages/8))
    db.wheelPage=math.max(1,math.min(maxPage,db.wheelPage or 1))
    if wheelPageLabel then wheelPageLabel:SetText(db.wheelPage.." / "..maxPage) end
    for i=1,8 do
        local n=(db.wheelPage-1)*8+i
        local msg=db.messages[n]
        local label=wheelButtons[i].label
        if msg then
            -- Preserve full saying for sending; only shorten the visible label.
            local short=msg
            if #short>43 then short=short:sub(1,40).."..." end
            label:SetText(short)
        else label:SetText("") end
    end
end
function QuickCommsForever_ToggleWheel()
    if not db or not wheel then return end
    if wheel:IsShown() then closeWheel()
    elseif db.wheelEnabled then
        list:Hide()
        mini:Hide()
        db.listMinimized=false
        db.minimizedView="wheel"
        wheel:Show()
    else notice("Wheel disabled. Use /qcf wheel on.") end
end
-- Reorder messages while keeping radial-wheel assignments on the same sayings.
local function moveMessage(from, to)
    if not db or from < 1 or to < 1 or from > #db.messages or to > #db.messages or from == to then return end
    if db.listLocked then return end
    db.messages[from], db.messages[to] = db.messages[to], db.messages[from]
    db.pendingDelete = nil
    refresh()
    if updateWheel then updateWheel() end
end
local function buildRow(index, content)
    local row=CreateFrame("Frame",nil,content)
    row:SetHeight(38)
    row:SetPoint("TOPLEFT",0,-(index-1)*38)
    local bg=row:CreateTexture(nil,"BACKGROUND")
    bg:SetPoint("TOPLEFT",row,"TOPLEFT",1,-2)
    bg:SetPoint("BOTTOMRIGHT",row,"BOTTOMRIGHT",-1,2)
    bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    if index % 2 == 0 then bg:SetVertexColor(0.12,0.16,0.22,0.80)
    else bg:SetVertexColor(0.09,0.12,0.18,0.85) end
    local accent=row:CreateTexture(nil,"BORDER")
    accent:SetTexture("Interface\\Buttons\\WHITE8X8")
    accent:SetVertexColor(0.76,0.55,0.22,0.9)
    accent:SetPoint("TOPLEFT",row,"TOPLEFT",2,-4)
    accent:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",2,4)
    accent:SetWidth(2)
    local label=row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    label:SetPoint("LEFT",row,"LEFT",12,0)
    label:SetHeight(27)
    label:SetJustifyH("LEFT")
    label:SetWordWrap(false)
    row.label=label
    -- The entire row is a single send target when the list is locked.
    local sendButton=CreateFrame("Button",nil,row)
    sendButton:SetPoint("TOPLEFT",row,"TOPLEFT",0,0)
    sendButton:SetPoint("BOTTOMRIGHT",row,"BOTTOMRIGHT",0,0)
    sendButton:SetScript("OnClick",function()
        if db.listLocked then send(db.messages[index],db.wheelChannel or "AUTO") end
    end)
    sendButton:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight")
    row.sendButton=sendButton
    -- Edit controls are only visible in unlocked mode.
    local del=button(row,"Delete",54,23,function()
        if db.listLocked then return end
        StaticPopup_Show("QCF_DELETE_SAYING",db.messages[index],nil,index)
    end)
    del:SetPoint("RIGHT",row,"RIGHT",-4,0)
    local down=button(row,"v",23,23,function() moveMessage(index,index+1) end)
    down:SetPoint("RIGHT",del,"LEFT",-8,0)
    local up=button(row,"^",23,23,function() moveMessage(index,index-1) end)
    up:SetPoint("RIGHT",down,"LEFT",-3,0)
    row.up=up; row.down=down; row.delete=del
    rows[index]=row
end
local content
local function layoutRows()
    if not list or not content then return end
    local rowWidth=math.max(330,list:GetWidth()-70)
    content:SetWidth(rowWidth)
    for i=1,#rows do
        local row=rows[i]
        row:SetWidth(rowWidth)
        local locked=db.listLocked
        -- Reorder controls and chat buttons are mutually exclusive.
        -- This prevents accidental chat or reordering while arranging sayings.
        if locked then row.sendButton:Show() else row.sendButton:Hide() end
        if locked then row.up:Hide(); row.down:Hide(); row.delete:Hide()
        else row.up:Show(); row.down:Show(); row.delete:Show() end
        row.label:SetWidth(math.max(80,rowWidth-(locked and 25 or 165)))
        row.up:SetEnabled(i>1)
        row.down:SetEnabled(i<#db.messages)
    end
end
refresh=function()
    if not db or not content then return end
    for i=1,#db.messages do
        if not rows[i] then buildRow(i,content) end
        rows[i].label:SetText(i..". "..db.messages[i])
        rows[i]:Show()
    end
    for i=#db.messages+1,#rows do rows[i]:Hide() end
    content:SetHeight(math.max(1,#db.messages*38))
    layoutRows()
    if helpText then
        helpText:SetText(db.listLocked and "Click a saying to send to the selected channel | Drag corner to resize" or "EDIT MODE: reorder or delete | Lock Order when finished")
    end
    if updateWheel then updateWheel() end
end
deleteMessage=function(n)
    if not db or not db.messages[n] then return end
    table.remove(db.messages,n)
    db.pendingDelete=nil
    refresh()
    notice("Saying deleted; radial wheel updated.")
end
StaticPopupDialogs["QCF_DELETE_SAYING"] = {
    text = "Delete this saved saying?\n%s",
    button1 = "Delete",
    button2 = "Cancel",
    OnAccept = function(self, data) if data and not db.listLocked then deleteMessage(data) end end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}
local function makeMini()
    mini=CreateFrame("Frame","QuickCommsForeverMini",UIParent,"BackdropTemplate")
    mini:SetSize(102,34)
    mini:SetFrameStrata("DIALOG")
    mini:SetMovable(true)
    mini:EnableMouse(true)
    mini:RegisterForDrag("LeftButton")
    mini:SetClampedToScreen(true)
    mini:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=14,insets={left=4,right=4,top=4,bottom=4}})
    mini:ClearAllPoints()
    mini:SetPoint("CENTER",UIParent,"CENTER",db.miniX or 0,db.miniY or 0)
    mini:SetScript("OnDragStart",function(self) self:StartMoving() end)
    mini:SetScript("OnDragStop",function(self) self:StopMovingOrSizing();saveMiniPosition() end)
    local title=mini:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("LEFT",mini,"LEFT",12,0)
    title:SetText("QCF")
    local expand=button(mini,"+",29,23,expandMinimized)
    expand:SetPoint("RIGHT",mini,"RIGHT",-7,0)
    expand:SetScript("OnEnter",function(self) GameTooltip:SetOwner(self,"ANCHOR_TOP");GameTooltip:SetText("Expand Quick Comms Forever");GameTooltip:Show() end)
    expand:SetScript("OnLeave",function() GameTooltip:Hide() end)
    mini:Hide()
end
local function makeList()
    list=makeFrame("QuickCommsForeverFrame",480,390)
    list:SetMovable(true); list:EnableMouse(true); list:RegisterForDrag("LeftButton")
    list:SetResizable(true)
    if list.SetMinResize then list:SetMinResize(400,280) end
    if list.SetMaxResize then list:SetMaxResize(900,800) end
    list:SetScript("OnDragStart",function(self) self:StartMoving() end)
    list:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
    local title=list:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    title:SetPoint("TOP",0,-18); title:SetText("Quick Comms Forever")
    title:SetTextColor(1,0.79,0.38)
    local headerLine=list:CreateTexture(nil,"ARTWORK")
    headerLine:SetTexture("Interface\\Buttons\\WHITE8X8")
    headerLine:SetVertexColor(0.70,0.51,0.22,0.8)
    headerLine:SetPoint("TOPLEFT",list,"TOPLEFT",20,-109)
    headerLine:SetPoint("TOPRIGHT",list,"TOPRIGHT",-20,-109)
    headerLine:SetHeight(1)
    local minimize=button(list,"_",25,22,minimizeList)
    minimize:SetPoint("TOPRIGHT",list,"TOPRIGHT",-12,-10)
    minimize:SetScript("OnEnter",function(self) GameTooltip:SetOwner(self,"ANCHOR_TOP");GameTooltip:SetText("Minimize to QCF box");GameTooltip:Show() end)
    minimize:SetScript("OnLeave",function() GameTooltip:Hide() end)
    local scroll=CreateFrame("ScrollFrame","QuickCommsForeverScroll",list,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",18,-72); scroll:SetPoint("BOTTOMRIGHT",-34,110)
    content=CreateFrame("Frame",nil,scroll)
    content:SetSize(410,1); scroll:SetScrollChild(content)
    local input=CreateFrame("EditBox","QuickCommsForeverInput",list,"InputBoxTemplate")
    input:SetSize(290,24); input:SetAutoFocus(false)
    input:SetPoint("BOTTOMLEFT",25,73)
    input:SetMaxLetters(255)
    local entryLabel=list:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    entryLabel:SetPoint("BOTTOMLEFT",input,"TOPLEFT",0,5)
    entryLabel:SetText("NEW COMMUNICATION")
    entryLabel:SetTextColor(0.93,0.73,0.37)
    input:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
    local function add()
        if not db then return end
        local value=input:GetText():match("^%s*(.-)%s*$")
        if value=="" then return end
        if #value>255 then notice("Messages must be 255 characters or fewer."); return end
        table.insert(db.messages,value)
        input:SetText(""); input:ClearFocus(); refresh()
    end
    input:SetScript("OnEnterPressed",add)
    local addButton=button(list,"Add",70,24,add)
    listChannelButton=button(list,"Chat: " .. (db.wheelChannel or "AUTO"),135,24,cycleWheelChannel)
    listChannelButton:SetPoint("TOPLEFT",list,"TOPLEFT",24,-78)
    scroll:ClearAllPoints()
    scroll:SetPoint("TOPLEFT",18,-118)
    scroll:SetPoint("BOTTOMRIGHT",-34,110)
    local wheelButton=button(list,"Wheel View",100,24,QuickCommsForever_ToggleWheel)
    wheelButton:SetPoint("BOTTOMLEFT",24,39)
    local optionsButton=button(list,"Options",82,24,toggleOptions)
    optionsButton:SetPoint("BOTTOMLEFT",24,12)
    -- Resize grip, anchored to the bottom-right corner.
    local grip=CreateFrame("Button",nil,list)
    grip:SetSize(22,22);grip:SetPoint("BOTTOMRIGHT",-9,9)
    local gripTex=grip:CreateTexture(nil,"OVERLAY")
    gripTex:SetAllPoints(grip)
    gripTex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetNormalTexture(gripTex)
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetScript("OnMouseDown",function(self,mouse)
        if mouse=="LeftButton" then list:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp",function(self)
        list:StopMovingOrSizing()
        db.listWidth=list:GetWidth();db.listHeight=list:GetHeight()
    end)
    -- Anchor Add to the window first, then stretch the input to its left.
    -- Never create circular frame-anchor dependencies.
    addButton:ClearAllPoints()
    addButton:SetPoint("BOTTOMRIGHT",list,"BOTTOMRIGHT",-25,73)
    input:ClearAllPoints()
    input:SetPoint("BOTTOMLEFT",list,"BOTTOMLEFT",25,73)
    input:SetPoint("RIGHT",addButton,"LEFT",-10,0)
    local function layout()
        layoutRows()
    end
    list:SetScript("OnSizeChanged",layout)
    if db.listWidth and db.listHeight then
        list:SetSize(math.max(400,math.min(900,db.listWidth)),math.max(280,math.min(800,db.listHeight)))
    end
    helpText=list:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    helpText:SetPoint("TOPLEFT",list,"TOPLEFT",24,-43)
    helpText:SetPoint("RIGHT",list,"RIGHT",-24,0)
    helpText:SetJustifyH("LEFT")
    helpText:SetJustifyV("TOP")
    helpText:SetWordWrap(true)
    helpText:SetNonSpaceWrap(true)
    helpText:SetHeight(32)
    helpText:SetText("Click a saying to send to the selected channel | Drag corner to resize")
end
local function makeOptions()
    optionsPanel=makeFrame("QuickCommsForeverOptions",355,390)
    optionsPanel:SetFrameStrata("FULLSCREEN_DIALOG")
    optionsPanel:SetMovable(true);optionsPanel:EnableMouse(true);optionsPanel:RegisterForDrag("LeftButton")
    optionsPanel:SetScript("OnDragStart",function(self) self:StartMoving() end)
    optionsPanel:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
    local title=optionsPanel:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    title:SetPoint("TOP",0,-22);title:SetText("QCF Options")
    local close=button(optionsPanel,"Close",70,24,function() optionsPanel:Hide() end)
    close:SetPoint("BOTTOM",0,20)
    local function checkbox(text,y,read,write)
        local cb=CreateFrame("CheckButton",nil,optionsPanel,"UICheckButtonTemplate")
        cb:SetPoint("TOPLEFT",24,y)
        local label=optionsPanel:CreateFontString(nil,"OVERLAY","GameFontHighlight")
        label:SetPoint("LEFT",cb,"RIGHT",5,0);label:SetText(text)
        cb:SetScript("OnClick",function(self) write(self:GetChecked() and true or false) end)
        return function() cb:SetChecked(read()) end
    end
    local checks={}
    checks[1]=checkbox("Enable radial wheel",-96,function() return db.wheelEnabled end,function(v) db.wheelEnabled=v;if not v then closeWheel() end end)
    checks[2]=checkbox("Show list / QCF box on login",-132,function() return db.showOnLogin end,function(v) db.showOnLogin=v end)
    checks[3]=checkbox("Lock saved saying positions",-168,function() return db.listLocked end,function(v) db.listLocked=v;refresh() end)
    local channelLabel=optionsPanel:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    channelLabel:SetPoint("TOPLEFT",33,-220);channelLabel:SetText("Wheel channel:")
    local channelButton=button(optionsPanel,"Auto",100,24,function()
        cycleWheelChannel()
        refreshOptions()
    end)
    channelButton:SetPoint("LEFT",channelLabel,"RIGHT",15,0)
    local scaleLabel=optionsPanel:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    scaleLabel:SetPoint("TOPLEFT",33,-264);scaleLabel:SetText("Wheel size:")
    local smaller=button(optionsPanel,"-",32,24,function()
        db.wheelScale=math.max(0.6,math.floor(((db.wheelScale or 1)-0.1)*10+0.5)/10)
        applyWheelScale();refreshOptions()
    end)
    smaller:SetPoint("LEFT",scaleLabel,"RIGHT",19,0)
    local scaleValue=optionsPanel:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    scaleValue:SetPoint("LEFT",smaller,"RIGHT",12,0)
    local larger=button(optionsPanel,"+",32,24,function()
        db.wheelScale=math.min(1.6,math.floor(((db.wheelScale or 1)+0.1)*10+0.5)/10)
        applyWheelScale();refreshOptions()
    end)
    larger:SetPoint("LEFT",scaleValue,"RIGHT",12,0)
    local reset=button(optionsPanel,"Center Wheel",130,24,function()
        db.wheelX=0;db.wheelY=0;applyWheelScale()
    end)
    reset:SetPoint("TOPLEFT",33,-306)
    local hint=optionsPanel:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    hint:SetPoint("TOPLEFT",optionsPanel,"TOPLEFT",24,-45)
    hint:SetPoint("RIGHT",optionsPanel,"RIGHT",-24,0)
    hint:SetJustifyH("LEFT")
    hint:SetJustifyV("TOP")
    hint:SetWordWrap(true)
    hint:SetNonSpaceWrap(true)
    hint:SetHeight(34)
    hint:SetText("Drag wheel center to move. Settings are saved.")
    refreshOptions=function()
        for i=1,#checks do checks[i]() end
        channelButton:SetText(db.wheelChannel)
        scaleValue:SetText(math.floor((db.wheelScale or 1)*100+0.5).."%")
    end
    optionsPanel:Hide()
end
local function initialize()
    QuickCommsForeverDB=QuickCommsForeverDB or {}
    db=QuickCommsForeverDB
    if db.listLocked==nil then db.listLocked=true end
    if db.showOnLogin==nil then db.showOnLogin=true end
    if type(db.wheelScale)~="number" then db.wheelScale=1 end
    db.wheelScale=math.max(0.6,math.min(1.6,db.wheelScale))
    if type(db.messages)~="table" then db.messages={"Ready to pull?","Wait for mana!","Incoming enemies!","Thanks everyone!"} end
    -- Legacy slot overrides are intentionally discarded: wheel pages read
    -- directly from the single authoritative saved-message list.
    db.slots=nil
    if type(db.wheelPage)~="number" then db.wheelPage=1 end
    if db.wheelEnabled==nil then db.wheelEnabled=true end
    if db.wheelChannel~="AUTO" and db.wheelChannel~="PARTY" and db.wheelChannel~="RAID" and db.wheelChannel~="SAY" and db.wheelChannel~="YELL" then db.wheelChannel="AUTO" end
    makeList(); makeMini(); makeWheel(); makeOptions(); refresh()
    if db.showOnLogin then
        if db.listMinimized then mini:Show() else list:Show() end
    end
    notice("Loaded v2.0.0. Wheel syncs directly with saved sayings; use wheel pages for more than 8.")
end
local eventFrame=CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:SetScript("OnEvent",function(self,event,name)
    if name==addonName or name=="QuickCommsForever" then
        self:UnregisterEvent("ADDON_LOADED")
        initialize()
    end
end)
SLASH_QUICKCOMMSFOREVER1="/qcf"
SLASH_QUICKCOMMSFOREVER2="/quickcomms"
SlashCmdList.QUICKCOMMSFOREVER=function(command)
    if not db then notice("Addon not initialized yet."); return end
    local cmd=(command or ""):match("^%s*(.-)%s*$"):lower()
    if cmd=="show" or cmd=="list" then expandList()
    elseif cmd=="hide" then list:Hide(); mini:Hide(); db.listMinimized=false
    elseif cmd=="minimize" or cmd=="mini" then minimizeList()
    elseif cmd=="expand" or cmd=="restore" then expandMinimized()
    elseif cmd=="lock" then db.listLocked=true; refresh(); notice("List order locked.")
    elseif cmd=="unlock" then db.listLocked=false; refresh(); notice("Reorder mode enabled. Chat buttons hidden.")
    elseif cmd=="options" or cmd=="settings" then toggleOptions()
    elseif cmd=="wheel" then QuickCommsForever_ToggleWheel()
    elseif cmd=="wheel on" then db.wheelEnabled=true; notice("Wheel enabled.")
    elseif cmd=="wheel off" then db.wheelEnabled=false; closeWheel(); notice("Wheel disabled.")
    elseif cmd:match("^channel ") then
        local channel=cmd:match("^channel%s+(%S+)$")
        if channel=="auto" or channel=="party" or channel=="raid" or channel=="say" or channel=="yell" then
            db.wheelChannel=channel:upper()
            if listChannelButton then listChannelButton:SetText("Chat: "..db.wheelChannel) end
            if wheelChannelButton then wheelChannelButton:SetText("Chat: "..db.wheelChannel) end
            if refreshOptions then refreshOptions() end
            notice("Chat channel: "..db.wheelChannel)
        else notice("Use /qcf channel auto|raid|party|say|yell") end
    elseif cmd:match("^slot ") then
        notice("Wheel now mirrors the list directly. Reorder sayings in Options to change wheel order.")
    elseif cmd=="wheel next" then
        db.wheelPage=math.min(math.max(1,math.ceil(#db.messages/8)),(db.wheelPage or 1)+1);updateWheel()
    elseif cmd=="wheel prev" then
        db.wheelPage=math.max(1,(db.wheelPage or 1)-1);updateWheel()
    elseif cmd:match("^remove%s+%d+$") then
        local n=tonumber(cmd:match("%d+"))
        if db.messages[n] then
            db.pendingDelete=n
            notice("Confirm removal of #"..n.." ("..db.messages[n].."): /qcf confirm")
        else notice("No saying with that number.") end
    elseif cmd=="confirm" then
        local n=db.pendingDelete
        if n and db.messages[n] then deleteMessage(n)
        else notice("No pending removal.") end
        db.pendingDelete=nil
    elseif cmd=="cancel" then
        db.pendingDelete=nil;notice("Removal cancelled.")
    elseif cmd=="help" then
        notice("/qcf list|wheel|minimize|expand|options | /qcf wheel on|off")
        notice("/qcf channel auto|raid|party|say|yell | /qcf wheel next|prev")
        notice("Remove safely: /qcf remove <number>, then /qcf confirm (or /qcf cancel).")
        notice("Use Options > Lock saved saying positions to switch between sending and editing.")
        notice("Wheel reads the list directly, 8 sayings per page. Use arrows to change pages.")
        notice("Assign Toggle Quick Comms Wheel in Key Bindings. Press key, click saying to send.")
    else
        if list:IsShown() then minimizeList() else expandList() end
    end
end
