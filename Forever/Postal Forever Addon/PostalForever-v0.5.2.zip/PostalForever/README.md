# PostalForever v0.5.2 (beta)

WoW Forever mailbox addon. Back up SavedVariables and replace the old PostalForever folder.

## New inbox actions
- Check individual messages beside the native inbox mail icons; use the native mailbox page controls and click **Open Selected**. **Select all** checks boxes only. **Clear** unchecks them.
- **Open All** collects eligible money and attachments from all senders (COD skipped).
- **Open Auction Mail** collects eligible messages whose sender contains the configured text. Default: `Auction House`. Verify the sender in your game and set it with `/pf auctionfrom Auction House`. This matches the sender text, not mail subject or auction outcome; won-auction and sale mail from that sender may both match.
- **Collect Gold** takes only money from eligible messages, leaving item attachments untouched. COD skipped.
- **Ctrl+Click Batch Attach** attempts to attach matching item IDs from bags to the Send Mail page, subject to client API availability and attachment limits. Never sends automatically. Check the recipient and attachments before sending. `/pf batch` toggles it.

## Commands
`/pf open` — Open all eligible mail
`/pf selected` — Open checked mail
`/pf select 1 3 5` — Toggle mail indices
`/pf gold` — Collect gold only
`/pf auction` — Collect mail matching Auction House sender
`/pf auctionfrom TEXT` — Set auction sender match (substring, case-insensitive)
`/pf batch` — Toggle Ctrl+Click batch attach
`/pf stop` — Stop collection
`/pf help` — Other commands

## Testing and limits
This release is not tested in-game. The client's mail API and Ctrl+Click hooks may differ. Always test with low-value items first. Inbox selection uses message indices and is cleared on unsolicited inbox updates to prevent checking the wrong message after a reorder. Native mailing confirmations remain enforced.

## v0.5.2
- Restores automatic outgoing subject from the first attachment, including batch attachments, when the subject is blank. Preserves manually edited subjects; clears addon-generated subject when attachments are removed.
