# PostalForever v0.3.0 - Account Characters

## What changed
The Account Characters window lets you add or remove `First-Last` names, such as `Slan-Suran`. Open it from the **Characters** button next to the mailbox or type `/pf alts`. Names persist in account-wide `PostalForeverDB`. Each character is registered when you log into it, unless you explicitly removed it.

**Important limitation:** WoW's addon API cannot enumerate every offline character on the character-selection screen. Log into each alt once to populate the list, or add the names manually. If the client exposes only a first name at login, manually add the full First-Last name; the addon cannot infer the surname.

## Commands
- `/pf alts` - open the account character list
- `/pf alts Suran` - list matching account characters
- `/pf alt Slan-Suran` - add a character
- `/pf removealt Slan-Suran` - remove a character and prevent automatic re-adding on login
- `/pf contacts` - list all saved recipients and alts
- `/pf forget Slan-Suran` - remove a recipient from both lists (use `/pf removealt` to prevent automatic re-registration)

## Install
Close WoW. Back up `WTF/Account/<account>/SavedVariables/PostalForever.lua`, then replace `Interface/AddOns/PostalForever` with this folder. Existing saved variables are retained.

## Caveats
This is a development build, not yet tested in the Forever client. The mailbox functions and UI depend on APIs available in your particular Forever build. Test with low-value mail.


## v0.3.1 - Recipient picker
Click the To: field to open PostalForever Recipients. Hover Account Alts or Recently Mailed, then hover a name to choose **Send to** or **Remove**. Removing an alt excludes it from automatic re-registration; removing a recent recipient only clears the history entry and does not remove the alt. Recently Mailed is populated after successful sends, when Remember recipients is enabled.

The list of alts is populated by logging into each character once or by adding it manually. The game addon API cannot enumerate never-logged-in offline characters.


## v0.3.2 recipient menu fix
Fixed nested menus for older dropdown APIs by reading `UIDROPDOWNMENU_MENU_VALUE` when the callback value is missing. Category rows now support click as well as hover. Clicking a character fills To; hovering reveals Send and Remove. If no alts appear, register with `/pf alt First-Last`.


## v0.3.3 — Automatic full-name alt registration
- On PLAYER_LOGIN and PLAYER_ENTERING_WORLD, attempts to read the current character's full First-Last name.
- Checks UnitFullName first, then GetUnitName and UnitName when they return a complete hyphenated name.
- Registers only complete names; never saves a first-name-only entry as a new alt.
- Keeps the existing account-wide SavedVariables roster, manual add/remove, and excluded character settings.
- `/pf scan` retries registration and reports whether it succeeded.
- Offline characters cannot be enumerated by the normal in-game addon API; log into each alt once or add it manually.
- IMPORTANT: If the client uses UnitFullName's second value for a realm instead of a surname, manually verify the captured name.
- Backup SavedVariables before upgrading; in-game testing is required.
