local _, PF = ...
-- Optional, user-initiated Ctrl+Click batching. Never sends mail automatically.
local function bagItemID(bag, slot)
 local fn = C_Container and C_Container.GetContainerItemID or GetContainerItemID
 if type(fn) ~= 'function' then return nil end
 local ok, id = pcall(fn, bag, slot)
 return ok and id or nil
end
local function bagSlots(bag)
 local fn = C_Container and C_Container.GetContainerNumSlots or GetContainerNumSlots
 if type(fn) ~= 'function' then return 0 end
 local ok, count = pcall(fn, bag)
 return ok and tonumber(count) or 0
end
local function pickup(bag, slot)
 local fn = C_Container and C_Container.PickupContainerItem or PickupContainerItem
 if type(fn) ~= 'function' then return false end
 return pcall(fn, bag, slot)
end
local function attachmentCount()
 local fn = C_Mail and C_Mail.GetSendMailItem or GetSendMailItem
 if type(fn) ~= 'function' then return nil end
 local count = 0
 for i=1,(ATTACHMENTS_MAX_SEND or 12) do
  local ok, item = pcall(fn,i)
  if ok and item then count=count+1 end
 end
 return count
end
function PF:BatchAttach(itemID)
 if not self.db or not self.db.batchAttach or not self.mailOpen or not SendMailFrame or not SendMailFrame:IsShown() then return end
 if not itemID then return end
 if type(ClickSendMailItemButton) ~= 'function' then self:Print('Batch attachment API unavailable'); return end
 local max = ATTACHMENTS_MAX_SEND or 12
 local used = attachmentCount()
 if not used then self:Print('Cannot verify attachment slots; batch attachment cancelled'); return end
 local added=0
 for bag=0,4 do
  for slot=1,bagSlots(bag) do
   if used>=max then break end
   if bagItemID(bag,slot)==itemID then
    if CursorHasItem and CursorHasItem() then break end
    if pickup(bag,slot) then
     local ok=pcall(ClickSendMailItemButton)
     if not ok then
      if ClearCursor then ClearCursor() end
      self:Print('Attachment failed; batch stopped'); return
     end
     local now=attachmentCount()
     if not now or now<=used then
      if ClearCursor then ClearCursor() end
      self:Print('Could not confirm attachment; batch stopped'); return
     end
     added=added+1; used=now
    end
   end
  end
  if used>=max then break end
 end
 self:Print('Added '..added..' matching bag slots; review attachments before sending.')
end
local function hookBatch()
 if PF.batchHooked or type(hooksecurefunc)~='function' then return end
 if type(ContainerFrameItemButton_OnModifiedClick)~='function' then return end
 hooksecurefunc('ContainerFrameItemButton_OnModifiedClick',function(button, mouseButton)
  if mouseButton~='LeftButton' or not IsControlKeyDown or not IsControlKeyDown() then return end
  if not button or not button.GetParent then return end
  local parent=button:GetParent()
  local bag=parent and parent.GetID and parent:GetID()
  local slot=button.GetID and button:GetID()
  if type(bag)~='number' or type(slot)~='number' then return end
  local id=bagItemID(bag,slot)
  if id then PF:BatchAttach(id) end
 end)
 PF.batchHooked=true
end
local frame=CreateFrame('Frame')
frame:RegisterEvent('PLAYER_LOGIN')
frame:SetScript('OnEvent',function() hookBatch() end)
