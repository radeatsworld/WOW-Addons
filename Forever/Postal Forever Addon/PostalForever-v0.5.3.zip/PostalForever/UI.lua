local _, PF = ...
local function button(parent, label, width, handler)
 local b = CreateFrame('Button',nil,parent,'UIPanelButtonTemplate')
 b:SetSize(width,23)
 b:SetText(label)
 b:SetScript('OnClick',handler)
 return b
end
function PF:ShowUI()
 if not MailFrame then self:Print('MailFrame unavailable'); return end
 if not self.panel then
  local p = CreateFrame('Frame','PostalForeverPanel',MailFrame,'BackdropTemplate')
  p:SetSize(405,112)
  p:SetPoint('TOPLEFT',MailFrame,'TOPRIGHT',3,-45)
  if p.SetBackdrop then p:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=12,insets={left=3,right=3,top=3,bottom=3}}) end
  local title = p:CreateFontString(nil,'OVERLAY','GameFontNormal')
  title:SetPoint('TOP',0,-8); title:SetText('PostalForever')
  p.status = p:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  p.status:SetPoint('BOTTOM',0,7)
  local all = button(p,'Open All',82,function() PF:StartOpen(false) end)
  all:SetPoint('TOPLEFT',9,-29)
  local selected = button(p,'Open Selected',100,function() PF:StartOpen(true) end)
  selected:SetPoint('LEFT',all,'RIGHT',3,0)
  local stop = button(p,'Stop',51,function() PF:Stop('Stopped') end)
  stop:SetPoint('LEFT',selected,'RIGHT',3,0)
  local options = button(p,'Options',70,function() PF:ToggleOptions() end)
  options:SetPoint('LEFT',stop,'RIGHT',3,0)
  local auction = button(p,'Open Auction Mail',145,function() PF:StartOpen('auction') end)
  auction:SetPoint('TOPLEFT',9,-57)
  local gold = button(p,'Collect Gold',105,function() PF:StartOpen('gold') end)
  gold:SetPoint('LEFT',auction,'RIGHT',5,0)
  self.panel = p
  local rosterButton = button(p,'Characters',100,function() PF:ShowCharacters() end)
  rosterButton:SetPoint('TOPRIGHT',p,'BOTTOMRIGHT',0,-4)
  self.rosterButton = rosterButton
  local optionsPanel = CreateFrame('Frame',nil,p,'BackdropTemplate')
  optionsPanel:SetSize(370,174)
  optionsPanel:SetPoint('TOPLEFT',p,'BOTTOMLEFT',0,-2)
  if optionsPanel.SetBackdrop then optionsPanel:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=12}) end
  local choices = {{'Auto collect','autoCollect'},{'Express','express'},{'Remember recipients','remember'},{'Mail history','log'},{'Trade block','tradeBlock'}}
  for i,choice in ipairs(choices) do
   local check = CreateFrame('CheckButton',nil,optionsPanel,'UICheckButtonTemplate')
   check:SetPoint('TOPLEFT',10,-(i-1)*27-9)
   check.text = check:CreateFontString(nil,'OVERLAY','GameFontHighlight')
   check.text:SetPoint('LEFT',check,'RIGHT',2,0); check.text:SetText(choice[1])
   check:SetScript('OnClick',function(self) PF.db[choice[2]] = self:GetChecked() and true or false end)
   check:SetScript('OnShow',function(self) self:SetChecked(PF.db[choice[2]]) end)
  end
  local note = optionsPanel:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  note:SetPoint('BOTTOMLEFT',12,9); note:SetText('Use /pf help for contacts, logs and delay.')
  optionsPanel:Hide()
  self.optionsPanel = optionsPanel
  local selectPanel = CreateFrame('Frame',nil,p)
  selectPanel:SetSize(405,48)
  selectPanel:SetPoint('TOPLEFT',p,'BOTTOMLEFT',0,-34)
  self.selectPanel = selectPanel
  local selectAll = button(selectPanel,'Select all',92,function()
   if PF.running then return end
   for i=1,PF:Count() do if PF:Collectable(i) then PF.db.selected[i] = true end end
   PF:RefreshUI()
  end)
  selectAll:SetPoint('TOPLEFT',0,0)
  local clear = button(selectPanel,'Clear',60,function() wipe(PF.db.selected); PF:RefreshUI() end)
  clear:SetPoint('LEFT',selectAll,'RIGHT',3,0)
  local ret = button(selectPanel,'Return next',100,function() PF:ReturnSelected() end)
  ret:SetPoint('LEFT',clear,'RIGHT',3,0)
  local del = button(selectPanel,'Delete empty',110,function() PF:DeleteSelected() end)
  del:SetPoint('LEFT',ret,'RIGHT',3,0)
  local hint = selectPanel:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  hint:SetPoint('TOPLEFT',2,-28); hint:SetText('Check mail in the Inbox, then click Open Selected. COD is skipped.')

 end
 self.panel:Show()
 self:HookInboxChecks()
 self:RefreshUI()
 self:HookSend()
end
function PF:ShowCharacters()
 if not self.db then return end
 if not self.roster then
  local frame = CreateFrame('Frame','PostalForeverRoster',UIParent,'BackdropTemplate')
  frame:SetSize(360,390)
  frame:SetPoint('CENTER',UIParent,'CENTER',0,0)
  frame:SetFrameStrata('DIALOG')
  frame:SetMovable(true); frame:EnableMouse(true)
  frame:RegisterForDrag('LeftButton')
  frame:SetScript('OnDragStart',frame.StartMoving)
  frame:SetScript('OnDragStop',frame.StopMovingOrSizing)
  if frame.SetBackdrop then frame:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=14,insets={left=4,right=4,top=4,bottom=4}}) end
  local title=frame:CreateFontString(nil,'OVERLAY','GameFontNormalLarge')
  title:SetPoint('TOPLEFT',14,-13); title:SetText('PostalForever - Account Characters')
  local close=button(frame,'X',28,function() frame:Hide() end)
  close:SetPoint('TOPRIGHT',-10,-9)
  local hint=frame:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  hint:SetPoint('TOPLEFT',14,-40)
  hint:SetText('Log into each alt once, or add a First-Last name below.')
  local edit=CreateFrame('EditBox',nil,frame,'InputBoxTemplate')
  edit:SetSize(218,24); edit:SetPoint('TOPLEFT',20,-65)
  edit:SetAutoFocus(false); edit:SetMaxLetters(100)
  local add=button(frame,'Add',83,function()
   local name=edit:GetText()
   if name and name ~= '' then PF:SaveAlt(name); edit:SetText(''); edit:ClearFocus() end
  end)
  add:SetPoint('LEFT',edit,'RIGHT',8,0)
  edit:SetScript('OnEnterPressed',function() add:Click() end)
  local scroll=CreateFrame('ScrollFrame','PostalForeverRosterScroll',frame,'FauxScrollFrameTemplate')
  scroll:SetPoint('TOPLEFT',14,-104); scroll:SetSize(320,250)
  scroll:SetScript('OnVerticalScroll',function(self,offset)
   FauxScrollFrame_OnVerticalScroll(self,offset,25,function() PF:RefreshCharacters() end)
  end)
  frame.rows={}
  for i=1,10 do
   local row=CreateFrame('Frame',nil,frame)
   row:SetSize(315,24); row:SetPoint('TOPLEFT',18,-105-(i-1)*25)
   row.label=row:CreateFontString(nil,'OVERLAY','GameFontHighlight')
   row.label:SetPoint('LEFT',0,0); row.label:SetWidth(218)
   row.label:SetJustifyH('LEFT')
   row.remove=button(row,'Remove',77,function()
    if row.character then PF:RemoveAlt(row.character) end
   end)
   row.remove:SetPoint('RIGHT',0,0)
   frame.rows[i]=row
  end
  local note=frame:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  note:SetPoint('BOTTOMLEFT',14,15)
  note:SetText('Names are shared across characters on this WoW account.')
  self.roster=frame
 end
 self.roster:Show()
 self:RefreshCharacters()
end
function PF:RefreshCharacters()
 if not self.roster or not self.db then return end
 local names=self:AccountCharacters()
 local scroll=PostalForeverRosterScroll
 FauxScrollFrame_Update(scroll,#names,10,25)
 local offset=FauxScrollFrame_GetOffset(scroll)
 for i,row in ipairs(self.roster.rows) do
  local name=names[i+offset]
  row.character=name
  if name then row.label:SetText(name); row:Show() else row:Hide() end
 end
end
function PF:ToggleOptions()
 if not self.optionsPanel then return end
 if self.optionsPanel:IsShown() then self.optionsPanel:Hide(); self.selectPanel:Show() else self.optionsPanel:Show(); self.selectPanel:Hide() end
end
function PF:HideUI() if self.panel then self.panel:Hide() end end
function PF:RefreshUI()
 if self.panel and self.db then
  local n = 0
  for i=1,self:Count() do if self.db.selected[i] then n=n+1 end end
  self.panel.status:SetText((self.running and 'Processing' or 'Ready')..' | '..self:Count()..' messages | '..n..' selected')
  self:RefreshInboxChecks()
 end
end
-- Attach to the native inbox rows, not a second list. The native update
-- function runs after page changes and repopulates each row's mail data.
function PF:RefreshInboxChecks()
 if not self.db then return end
 self.inboxChecks = self.inboxChecks or {}
 local visible = self.mailOpen and InboxFrame and InboxFrame:IsVisible()
 local perPage = tonumber(INBOXITEMS_TO_DISPLAY) or 7
 local page = tonumber(InboxFrame and InboxFrame.pageNum) or 1
 for i=1,perPage do
  local row = _G['MailItem'..i]
  local icon = _G['MailItem'..i..'Button'] or (row and row.Button)
  local cb = self.inboxChecks[i]
  if visible and row and icon and not cb then
   cb = CreateFrame('CheckButton',nil,InboxFrame,'UICheckButtonTemplate')
   cb:SetSize(18,18)
   -- Use the inbox as parent so the row artwork cannot clip the checkbox.
   -- Inset onto the icon's lower-left corner rather than the outer border.
   cb:SetPoint('BOTTOMLEFT',icon,'BOTTOMLEFT',2,2)
   cb:SetFrameStrata(InboxFrame:GetFrameStrata())
   cb:SetFrameLevel(math.max(row:GetFrameLevel(),icon:GetFrameLevel(),InboxFrame:GetFrameLevel())+10)
   cb:SetScript('OnClick',function(box)
    if PF.running or not box.index or not InboxFrame:IsVisible() then return end
    PF.db.selected[box.index] = box:GetChecked() and true or nil
    PF:RefreshUI()
   end)
   self.inboxChecks[i] = cb
  end
  if cb then
   local index = (math.max(1,page)-1)*perPage+i
   if visible and row and row:IsVisible() and index <= self:Count() and self:Header(index) then
    cb.index = index
    cb:SetChecked(self.db.selected[index] and true or false)
    if self.running then cb:Disable() else cb:Enable() end
    cb:Show()
   else cb.index=nil; cb:Hide() end
  end
 end
end
function PF:HookInboxChecks()
 if self.inboxChecksHooked or not InboxFrame then return end
 self.inboxChecksHooked = true
 if type(InboxFrame_Update)=='function' and type(hooksecurefunc)=='function' then
  hooksecurefunc('InboxFrame_Update',function() PF:RefreshInboxChecks() end)
 end
 InboxFrame:HookScript('OnShow',function() PF:RefreshInboxChecks() end)
 InboxFrame:HookScript('OnHide',function() PF:RefreshInboxChecks() end)
 -- Some clients use a different page update routine. Watch page changes too.
 local watcher=CreateFrame('Frame',nil,InboxFrame)
 local elapsed=0
 watcher:SetScript('OnUpdate',function(_,dt)
  elapsed=elapsed+dt
  if elapsed>=0.2 then elapsed=0; PF:RefreshInboxChecks() end
 end)
end
-- Older WoW dropdown implementations expose submenu values through the global
-- UIDROPDOWNMENU_MENU_VALUE, not always through the initialize callback argument.
-- Store each menu level's selection in the global-compatible string value.
function PF:ShowRecipientMenu(edit)
 if not self.db or not UIDropDownMenu_Initialize or not ToggleDropDownMenu then return end
 if not self.contactMenu then
  self.contactMenu = CreateFrame('Frame','PostalForeverContacts',UIParent,'UIDropDownMenuTemplate')
 end
 local menu = self.contactMenu
 local alts = self:AccountCharacters()
 local recent = self:RecentRecipients(30)
 local trusted = self:TrustedRecipients()
 local entries = {}
 local function add(info, level)
  info.notCheckable = true
  UIDropDownMenu_AddButton(info, level)
 end
 local function child(category, name)
  local key = category..':'..name
  entries[key] = {category=category, name=name}
  return key
 end
 local function choose(name)
  edit:SetText(name)
  if edit.SetCursorPosition then edit:SetCursorPosition(#name) end
  CloseDropDownMenus()
 end
 UIDropDownMenu_Initialize(menu,function(_, level, menuValue)
  level = level or 1
  -- This global is essential on clients where menuValue is nil at levels 2/3.
  local value = menuValue or UIDROPDOWNMENU_MENU_VALUE
  if level == 1 then
   local title = UIDropDownMenu_CreateInfo()
   title.text = 'PostalForever Recipients'; title.isTitle = true
   add(title,1)
   local alt = UIDropDownMenu_CreateInfo()
   alt.text = 'Account Alts ('..#alts..')'
   alt.value = 'alts'; alt.hasArrow = #alts > 0; alt.disabled = #alts == 0
   alt.keepShownOnClick = true
   alt.func = function()
    if #alts > 0 then ToggleDropDownMenu(2,'alts',menu,edit,0,0) end
   end
   add(alt,1)
   local rec = UIDropDownMenu_CreateInfo()
   rec.text = 'Recently Mailed ('..#recent..')'
   rec.value = 'recent'; rec.hasArrow = #recent > 0; rec.disabled = #recent == 0
   rec.keepShownOnClick = true
   rec.func = function()
    if #recent > 0 then ToggleDropDownMenu(2,'recent',menu,edit,0,0) end
   end
   add(rec,1)
   local trust = UIDropDownMenu_CreateInfo()
   trust.text = 'Trusted Recipients ('..#trusted..')'
   trust.value = 'trusted'; trust.hasArrow = #trusted > 0; trust.disabled = #trusted == 0
   trust.keepShownOnClick = true
   trust.func = function() if #trusted > 0 then ToggleDropDownMenu(2,'trusted',menu,edit,0,0) end end
   add(trust,1)
   local manage = UIDropDownMenu_CreateInfo()
   manage.text = 'Manage Account Characters...'
   manage.func = function() CloseDropDownMenus(); PF:ShowCharacters() end
   add(manage,1)
  elseif level == 2 then
   local list = value == 'alts' and alts or (value == 'recent' and recent or (value == 'trusted' and trusted or nil))
   if list then
    for _,name in ipairs(list) do
     local item = UIDropDownMenu_CreateInfo()
     item.text = name
     item.value = child(value,name)
     item.hasArrow = true
     item.keepShownOnClick = true
     item.func = function() choose(name) end
     add(item,2)
    end
   end
  elseif level == 3 then
   local entry = entries[value]
   if entry then
    local name, category = entry.name, entry.category
    local send = UIDropDownMenu_CreateInfo()
    send.text = 'Send to '..name
    send.func = function() choose(name) end
    add(send,3)
    local remove = UIDropDownMenu_CreateInfo()
    remove.text = category == 'alts' and 'Remove from Account Alts' or (category == 'trusted' and 'Remove from Trusted Recipients' or 'Remove from Recently Mailed')
    remove.func = function()
     if category == 'alts' then PF:RemoveAlt(name) elseif category == 'trusted' then PF:UntrustName(name) else PF:RemoveRecent(name) end
     CloseDropDownMenus()
    end
    add(remove,3)
   end
  end
 end,'MENU')
 ToggleDropDownMenu(1,nil,menu,edit,0,0)
end
function PF:HookSend()
 if not self.sendHooked and type(SendMail) == 'function' and type(hooksecurefunc) == 'function' then
  hooksecurefunc('SendMail',function(to,subject)
   PF.lastRecipient = to
   PF.lastSubject = subject
  end)
  self.sendHooked = true
 end
 if not self.recipientHooked and SendMailNameEditBox and SendMailNameEditBox.HookScript then
  -- Do not open on focus: WoW may focus the edit box when the mailbox opens,
  -- even while Inbox is active. Open only on an actual mouse click in To:.
  SendMailNameEditBox:HookScript('OnMouseUp',function(edit, mouseButton)
   if mouseButton ~= 'LeftButton' or not PF.mailOpen then return end
   if not SendMailFrame or not SendMailFrame:IsShown() or not edit:IsVisible() then return end
   PF:ShowRecipientMenu(edit)
  end)
  self.recipientHooked = true
 end
end
local oldSlash = SlashCmdList.POSTALFOREVER
SlashCmdList.POSTALFOREVER = function(msg)
 local command, args = (msg or ''):match('^(%S*)%s*(.-)%s*$')
 if command and command:lower() == 'select' then
  for token in args:gmatch('%d+') do
   local n = tonumber(token)
   if n and n >= 1 and n <= PF:Count() then PF.db.selected[n] = not PF.db.selected[n] end
  end
  PF:RefreshUI()
 elseif command and command:lower() == 'wirefill' then
  if SendMailMoney and MoneyInputFrame_SetCopper then MoneyInputFrame_SetCopper(SendMailMoney,PF.db.wireAmount) else PF:Print('Money input API unavailable') end
 else oldSlash(msg) end
end
