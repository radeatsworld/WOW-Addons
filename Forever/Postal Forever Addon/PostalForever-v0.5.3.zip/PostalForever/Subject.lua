local _, PF = ...
-- Fill only blank or addon-generated subjects; respect user edits.
local state = {}
local function firstItem()
 local fn = (C_Mail and C_Mail.GetSendMailItem) or GetSendMailItem
 if type(fn) ~= 'function' then return nil, false end
 for i=1,(ATTACHMENTS_MAX_SEND or 12) do
  local ok, item = pcall(fn,i)
  if not ok then return nil,false end
  if type(item)=='table' then item=item.name or item.itemName end
  if type(item)=='string' and item~='' then return item,true end
  if item then return nil,false end
 end
 return nil,true
end
local function update()
 local edit=SendMailSubjectEditBox
 if not PF.mailOpen or not SendMailFrame or not SendMailFrame:IsShown() or not edit then return end
 if not state.hooked or state.edit~=edit then
  if not edit.HookScript then return end
  edit:HookScript('OnTextChanged',function(_,userInput)
   if userInput and not state.writing then state.manual=true; state.auto=nil end
  end)
  state.hooked=true; state.edit=edit
 end
 local current=edit:GetText() or ''
 if state.manual then return end
 if current~='' and current~=state.auto then return end
 local name,known=firstItem()
 if not known then return end
 local desired=name or ''
 if current~=desired then
  state.writing=true; edit:SetText(desired); state.writing=false
 end
 state.auto=name
end
local frame=CreateFrame('Frame')
for _,event in ipairs({'MAIL_SHOW','MAIL_CLOSED','MAIL_SEND_SUCCESS','MAIL_SEND_INFO_UPDATE'}) do pcall(frame.RegisterEvent,frame,event) end
frame:SetScript('OnEvent',function(_,event)
 if event=='MAIL_SHOW' or event=='MAIL_CLOSED' or event=='MAIL_SEND_SUCCESS' then
  state.manual=nil; state.auto=nil
 end
end)
-- Poll as a fallback for clients that do not expose the attachment event.
local elapsed=0
frame:SetScript('OnUpdate',function(_,dt)
 if not PF.mailOpen then return end
 elapsed=elapsed+dt
 if elapsed>=0.15 then elapsed=0; update() end
end)
