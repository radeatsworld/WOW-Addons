local addonName, PF = ...
_G.PostalForever = PF
PF.version = '0.4.0'
PF.defaults = { openDelay = 0.65, autoCollect = false, express = true, tradeBlock = false, log = true, remember = true, wireAmount = 0, alts = {}, excludedAlts = {}, contacts = {}, history = {}, selected = {}, trusted = {}, mailAlert = true }
local function copyDefaults(target, source)
 for k,v in pairs(source) do
  if target[k] == nil then
   if type(v) == 'table' then target[k] = {}; copyDefaults(target[k], v) else target[k] = v end
  end
 end
end
function PF:Print(s) print('|cff58c7ffPostalForever:|r '..tostring(s)) end
function PF:Record(action, who, detail)
 if not self.db or not self.db.log then return end
 local history = self.db.history
 table.insert(history, 1, { time = time(), action = action, who = who or '?', detail = detail or '' })
 while #history > 250 do table.remove(history) end
end
-- Forever mail addresses use First-Last. A hyphen is NOT a realm separator.
-- Never remove a generic hyphen suffix. Only remove the exact legacy realm
-- string produced by earlier PostalForever builds.
function PF:NormalizeName(name)
 if type(name) ~= 'string' then return nil end
 name = name:match('^%s*(.-)%s*$'):gsub('%s+', ' ')
 if name == '' then return nil end
 return name
end
function PF:DisplayName(name)
 name = self:NormalizeName(name)
 if not name then return nil end
 local realm = GetRealmName and GetRealmName()
 realm = self:NormalizeName(realm)
 if realm and realm ~= '' then
  local suffix = '-' .. realm
  if name:sub(-#suffix):lower() == suffix:lower() then
   return self:NormalizeName(name:sub(1, #name - #suffix))
  end
 end
 return name
end
-- Forever mail recipients are First-Last, not Name-Realm.
-- Prefer a genuine two-part identity. Never assume UnitFullName's second
-- return value is a surname unless the Forever client supplies it as such.
function PF:PlayerName()
 local function complete(first, last)
  first, last = self:NormalizeName(first), self:NormalizeName(last)
  if first and last and not first:find('-', 1, true) and not last:find('-', 1, true) then
   return first .. '-' .. last
  end
 end
 if type(UnitFullName) == 'function' then
  local ok, first, last = pcall(UnitFullName, 'player')
  if ok then
   local full = complete(first, last)
   if full then return full, 'UnitFullName' end
   -- Some Forever builds expose the complete name in one return value.
   first = self:NormalizeName(first)
   if first and first:match('^[^%s%-]+%-%S+$') then return first, 'UnitFullName' end
  end
 end
 if type(GetUnitName) == 'function' then
  local ok, name = pcall(GetUnitName, 'player', true)
  name = ok and self:NormalizeName(name) or nil
  if name and name:match('^[^%s%-]+%-%S+$') then return name, 'GetUnitName' end
 end
 if type(UnitName) == 'function' then
  local ok, name = pcall(UnitName, 'player')
  name = ok and self:NormalizeName(name) or nil
  if name and name:match('^[^%s%-]+%-%S+$') then return name, 'UnitName' end
 end
 return nil, 'No full First-Last name supplied by client'
end
function PF:MigrateNames()
 -- Keep original records in a backup: earlier versions may have stripped
 -- real surnames. We cannot reconstruct a missing surname automatically.
 if self.db.nameMigrationV022 then return end
 self.db.preV022Names = self.db.preV022Names or {alts = {}, contacts = {}}
 for _,field in ipairs({'alts','contacts'}) do
  local tbl = self.db[field]
  for old,value in pairs(tbl) do
   self.db.preV022Names[field][old] = value
  end
  local changes = {}
  for old,value in pairs(tbl) do
   local clean = self:DisplayName(old)
   if clean and clean ~= old then changes[#changes+1] = {old,clean,value} end
  end
  for _,entry in ipairs(changes) do
   local old,clean,value = entry[1],entry[2],entry[3]
   if tbl[clean] == nil then tbl[clean] = value end
   tbl[old] = nil
  end
 end
 self.db.nameMigrationV022 = true
end
-- Trust is separate from alts and recent contacts. Only explicit approval
-- of a recognized native mail confirmation followed by successful sending
-- can add a recipient automatically.
function PF:TrustName(name, quiet)
 name = self:NormalizeName(name)
 if not name then return end
 self.db.trusted[name] = time()
 if not quiet then self:Print('Trusted recipient: '..name) end
end
function PF:UntrustName(name)
 name = self:NormalizeName(name)
 if not name then return end
 local removed = false
 for saved in pairs(self.db.trusted) do
  if saved:lower() == name:lower() then self.db.trusted[saved] = nil; removed = true end
 end
 self:Print(removed and ('Untrusted: '..name) or ('Not in trusted list: '..name))
end
function PF:TrustedRecipients()
 local names = {}
 for name in pairs(self.db.trusted) do names[#names+1] = name end
 table.sort(names,function(a,b) return a:lower() < b:lower() end)
 return names
end
-- Only record a native popup's OK when its visible warning clearly concerns
-- mailing the *current recipient*. A generic popup is never enough.
function PF:HookMailConfirmation()
 if self.confirmHooked or type(hooksecurefunc) ~= 'function' or type(StaticPopup_OnClick) ~= 'function' then return end
 hooksecurefunc('StaticPopup_OnClick', function(dialog, button)
  if button ~= 1 or not dialog or not PF.mailOpen then return end
  if not SendMailFrame or not SendMailFrame:IsShown() then return end
  local recipient = SendMailNameEditBox and PF:NormalizeName(SendMailNameEditBox:GetText())
  if not recipient or not dialog.which then return end
  local key = tostring(dialog.which):upper()
  -- The exact Forever popup identifier has not yet been verified. Require
  -- BOTH a mail-related identifier and recipient in the rendered warning.
  if not (key:find('MAIL',1,true) or key:find('SEND',1,true)) then return end
  local message = dialog.text and dialog.text.GetText and dialog.text:GetText() or ''
  if type(message) ~= 'string' or not message:lower():find(recipient:lower(),1,true) then return end
  PF.pendingTrustedRecipient = recipient
 end)
 self.confirmHooked = true
end
function PF:AddContact(name)
 if not self.db or not self.db.remember then return end
 name = self:DisplayName(name)
 if not name then return end
 self.db.contacts[name] = time()
end
-- Account-wide roster: the WoW addon sandbox cannot inspect offline characters.
-- Characters register on login, or can be entered manually using First-Last.
function PF:SaveAlt(name, quiet)
 name = self:DisplayName(name)
 if not name then if not quiet then self:Print('Use /pf alt First-Last') end; return end
 self.db.excludedAlts[name:lower()] = nil
 self.db.alts[name] = true
 if not quiet then self:Print('Account character saved: '..name) end
 if self.RefreshCharacters then self:RefreshCharacters() end
end
function PF:RemoveAlt(name)
 name = self:DisplayName(name)
 if not name then return end
 local found
 for saved in pairs(self.db.alts) do
  if saved:lower() == name:lower() then self.db.alts[saved] = nil; found = saved end
 end
 -- Exclusions stop a removed current character from being re-added at next login.
 self.db.excludedAlts[name:lower()] = true
 self:Print('Removed account character: '..(found or name))
 if self.RefreshCharacters then self:RefreshCharacters() end
end
function PF:AccountCharacters(filter)
 local names = {}
 filter = (filter or ''):lower()
 for name in pairs(self.db.alts) do
  if name:lower():find(filter,1,true) then names[#names+1] = name end
 end
 table.sort(names,function(a,b) return a:lower() < b:lower() end)
 return names
end
function PF:RegisterCurrentCharacter()
 if not self.db then return end
 local name, source = self:PlayerName()
 if not name then
  self.lastRegistration = 'Not registered: '..tostring(source)
  return
 end
 local lower = name:lower()
 if self.db.excludedAlts[lower] then
  self.lastRegistration = 'Excluded: '..name
  return
 end
 for saved in pairs(self.db.alts) do
  if saved:lower() == lower then
   self.lastRegistration = 'Already saved: '..saved
   return
  end
 end
 self.db.alts[name] = true
 self.lastRegistration = 'Saved '..name..' via '..source
 if self.RefreshCharacters then self:RefreshCharacters() end
end
-- Recently mailed recipients are ordered by the last successful send.
-- Existing contact timestamps from earlier versions are retained.
function PF:RecentRecipients(limit)
 local names = {}
 for name, stamp in pairs(self.db.contacts or {}) do
  local clean = self:DisplayName(name)
  if clean then names[#names+1] = {name=clean, stamp=tonumber(stamp) or 0} end
 end
 table.sort(names, function(a,b)
  if a.stamp == b.stamp then return a.name:lower() < b.name:lower() end
  return a.stamp > b.stamp
 end)
 local result, seen = {}, {}
 for _,entry in ipairs(names) do
  local key = entry.name:lower()
  if not seen[key] then
   result[#result+1] = entry.name
   seen[key] = true
   if limit and #result >= limit then break end
  end
 end
 return result
end
function PF:RemoveRecent(name)
 name = self:DisplayName(name)
 if not name then return end
 for saved in pairs(self.db.contacts) do
  if saved:lower() == name:lower() then self.db.contacts[saved] = nil end
 end
 self:Print('Removed recent recipient: '..name)
end
function PF:Contacts(filter)
 local result, seen = {}, {}
 filter = filter and filter:lower() or ''
 for _,field in ipairs({'contacts','alts'}) do
  for name in pairs(self.db[field]) do
   local clean = self:DisplayName(name)
   if clean and not seen[clean:lower()] and clean:lower():find(filter,1,true) then
    result[#result+1] = clean
    seen[clean:lower()] = true
   end
  end
 end
 table.sort(result, function(a,b) return a:lower() < b:lower() end)
 return result
end
function PF:ToggleOption(name)
 self.db[name] = not self.db[name]
 self:Print(name..': '..(self.db[name] and 'on' or 'off'))
end
SLASH_POSTALFOREVER1 = '/pf'
SLASH_POSTALFOREVER2 = '/postalforever'
SlashCmdList.POSTALFOREVER = function(msg)
 local command, rest = (msg or ''):match('^(%S*)%s*(.-)%s*$')
 command = command:lower()
 if command == 'open' then PF:StartOpen(false)
 elseif command == 'selected' then PF:StartOpen(true)
 elseif command == 'stop' then PF:Stop('Stopped')
 elseif command == 'alt' and rest ~= '' then PF:SaveAlt(rest)
 elseif command == 'removealt' and rest ~= '' then PF:RemoveAlt(rest)
 elseif command == 'trust' and rest ~= '' then PF:TrustName(rest)
 elseif command == 'untrust' and rest ~= '' then PF:UntrustName(rest)
 elseif command == 'trusted' then PF:Print('Trusted recipients: '..table.concat(PF:TrustedRecipients(), ', '))
 elseif command == 'mailalert' then
  local arg = rest:lower()
  if arg == 'on' then PF.db.mailAlert = true; PF:Print('Mail alerts enabled'); if PF.CheckMailAlert then PF:CheckMailAlert() end
  elseif arg == 'off' then PF.db.mailAlert = false; PF:Print('Mail alerts disabled')
  elseif arg == 'test' then if PF.PlayMailAlert then PF:PlayMailAlert() end
  elseif arg == 'status' then PF:Print('Mail alerts: '..(PF.db.mailAlert and 'on' or 'off'))
  else PF:Print('Use /pf mailalert on, off, test, or status') end
 elseif command == 'scan' then PF:RegisterCurrentCharacter(); PF:Print(PF.lastRegistration or 'Scan unavailable')
 elseif command == 'alts' then PF:Print('Account characters: '..table.concat(PF:AccountCharacters(rest), ', ')); if PF.ShowCharacters then PF:ShowCharacters() end
 elseif command == 'forget' and rest ~= '' then local name = PF:DisplayName(rest); if name then PF.db.alts[name] = nil; PF.db.contacts[name] = nil; PF:Print('Removed '..name) end
 elseif command == 'contacts' then PF:Print(table.concat(PF:Contacts(rest), ', '))
 elseif command == 'log' then
  for i = 1, math.min(15, #PF.db.history) do local e = PF.db.history[i]; PF:Print(date('%m/%d %H:%M', e.time)..' '..e.action..' '..e.who..' '..e.detail) end
 elseif command == 'auto' or command == 'express' or command == 'tradeblock' or command == 'remember' or command == 'logging' then
  PF:ToggleOption(({auto='autoCollect',express='express',tradeblock='tradeBlock',remember='remember',logging='log'})[command])
 elseif command == 'delay' then local n = tonumber(rest); if n and n >= 0.3 and n <= 5 then PF.db.openDelay = n; PF:Print('Delay: '..n..'s') else PF:Print('Use /pf delay 0.3 to 5') end
 elseif command == 'wire' then local n = tonumber(rest); if n and n >= 0 then PF.db.wireAmount = math.floor(n); PF:Print('Wire amount set to '..n..' copper') end
 elseif command == 'help' or command == '' then
  PF:Print('/pf open, selected, stop, scan, alts [SEARCH], alt FIRST-LAST, removealt FIRST-LAST')
  PF:Print('/pf forget FIRST-LAST, contacts [SEARCH], log')
  PF:Print('/pf trusted, trust FIRST-LAST, untrust FIRST-LAST')
  PF:Print('/pf mailalert on, off, test, status')
  PF:Print('/pf auto, express, tradeblock, remember, logging, delay SECONDS, wire COPPER')
 else PF:Print('Unknown command. Type /pf help') end
end
local f = CreateFrame('Frame')
f:RegisterEvent('PLAYER_LOGIN')
f:RegisterEvent('PLAYER_ENTERING_WORLD')
f:RegisterEvent('MAIL_SHOW')
f:RegisterEvent('MAIL_CLOSED')
f:RegisterEvent('MAIL_SEND_SUCCESS')
f:RegisterEvent('MAIL_FAILED')
f:RegisterEvent('MAIL_INBOX_UPDATE')
f:SetScript('OnEvent', function(_, event, ...)
 if event == 'PLAYER_LOGIN' then
  PostalForeverDB = PostalForeverDB or {}
  copyDefaults(PostalForeverDB, PF.defaults)
  PF.db = PostalForeverDB
  PF:MigrateNames()
  PF:RegisterCurrentCharacter()
  PF:HookMailConfirmation()
  PF:Print('Loaded v'..PF.version..'. Type /pf help.')
 elseif event == 'PLAYER_ENTERING_WORLD' then
  PF:RegisterCurrentCharacter()
 elseif event == 'MAIL_SHOW' then
  PF.mailOpen = true
  PF:ShowUI()
  if PF.db.autoCollect then PF:StartOpen(false) end
 elseif event == 'MAIL_CLOSED' then PF.pendingTrustedRecipient = nil; PF.mailOpen = false; PF:Stop(nil); PF:HideUI()
 elseif event == 'MAIL_FAILED' then PF.pendingTrustedRecipient = nil; PF:Stop('Mail operation failed')
 elseif event == 'MAIL_SEND_SUCCESS' then PF:OnSendSuccess()
 elseif event == 'MAIL_INBOX_UPDATE' then PF:OnInboxUpdate(); PF:RefreshUI() end
end)
