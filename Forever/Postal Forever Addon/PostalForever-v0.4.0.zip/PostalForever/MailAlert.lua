-- PostalForever mail notification module, adapted from YouveGotMailForever v1.1.1.
local addonName, PF = ...
local soundPath = "Interface\\AddOns\\PostalForever\\Sounds\\youvegotmail.mp3"
local announced = false
local pending = false
local initialized = false

function PF:PlayMailAlert()
 if type(PlaySoundFile) ~= 'function' then self:Print('Sound playback is unavailable on this client.'); return end
 local ok, result = pcall(PlaySoundFile, soundPath, 'Master')
 if not ok or result == false then self:Print('Unable to play Sounds\\youvegotmail.mp3; check sound settings and file encoding.') end
end

local function HasPendingMail()
 if type(HasNewMail) == 'function' then
  local ok, result = pcall(HasNewMail)
  if ok and type(result) == 'boolean' then return result end
 end
 if MiniMapMailFrame and type(MiniMapMailFrame.IsShown) == 'function' then
  local ok, result = pcall(MiniMapMailFrame.IsShown, MiniMapMailFrame)
  if ok and type(result) == 'boolean' then return result end
 end
 return nil
end

function PF:CheckMailAlert()
 pending = false
 if not initialized or not self.db or self.db.mailAlert == false then return end
 local hasMail = HasPendingMail()
 if hasMail == true and not announced then
  announced = true
  self:PlayMailAlert()
 elseif hasMail == false then
  announced = false
 end
end

local function QueueCheck()
 if pending then return end
 pending = true
 if C_Timer and type(C_Timer.After) == 'function' then
  C_Timer.After(0.5, function() PF:CheckMailAlert() end)
 else
  PF:CheckMailAlert()
 end
end

local frame = CreateFrame('Frame')
frame:RegisterEvent('PLAYER_LOGIN')
frame:RegisterEvent('PLAYER_ENTERING_WORLD')
frame:RegisterEvent('UPDATE_PENDING_MAIL')
frame:RegisterEvent('MAIL_INBOX_UPDATE')
frame:RegisterEvent('MAIL_SHOW')
frame:SetScript('OnEvent', function(_, event)
 if event == 'PLAYER_LOGIN' then
  initialized = true
  QueueCheck()
 elseif event == 'PLAYER_ENTERING_WORLD' then
  announced = false
  QueueCheck()
  if C_Timer and type(C_Timer.After) == 'function' then C_Timer.After(3, function() PF:CheckMailAlert() end) end
 else QueueCheck() end
end)
