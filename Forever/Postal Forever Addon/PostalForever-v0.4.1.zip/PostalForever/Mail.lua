local _, PF = ...
local M = C_Mail or {}
local function invoke(fn, ...)
 if type(fn) ~= 'function' then return false, 'API unavailable' end
 return pcall(fn, ...)
end
local function getHeader(index)
 local fn = M.GetInboxHeaderInfo or GetInboxHeaderInfo
 if type(fn) ~= 'function' then return nil end
 local ok, a,b,c,d,e,f,g,h,i,j,k,l,m = pcall(fn,index)
 if not ok then return nil end
 if type(a) == 'table' then
  return { sender = a.sender or '?', subject = a.subject or '', money = a.money or 0, cod = a.codAmount or a.CODAmount or 0, items = a.numAttachments or a.itemCount or 0, wasRead = a.wasRead, canReply = a.canReply }
 end
 return { sender = c or '?', subject = d or '', money = e or 0, cod = f or 0, items = h or 0, wasRead = j, canReply = k }
end
function PF:Count()
 local fn = M.GetInboxNumItems or GetInboxNumItems
 if type(fn) ~= 'function' then return 0 end
 local ok, count = pcall(fn)
 return ok and tonumber(count) or 0
end
function PF:Header(i) return getHeader(i) end
function PF:Collectable(i)
 local h = self:Header(i)
 if not h or (tonumber(h.cod) or 0) > 0 then return false end
 return (tonumber(h.money) or 0) > 0 or (tonumber(h.items) or 0) > 0
end
function PF:Stop(message)
 if self.worker then self.worker:SetScript('OnUpdate',nil) end
 self.running = false
 self.pending = nil
 if message then self:Print(message) end
 if self.RefreshUI then self:RefreshUI() end
end
function PF:StartOpen(selectedOnly)
 if not self.mailOpen then self:Print('Open a mailbox first.'); return end
 if self.running then return end
 if type(M.TakeInboxMoney or TakeInboxMoney) ~= 'function' or type(M.TakeInboxItem or TakeInboxItem) ~= 'function' then
  self:Print('Required mail collection APIs are unavailable.'); return
 end
 self.running = true
 self.selectedOnly = selectedOnly
 self.cursor = self:Count()
 self.elapsed = 0
 self.pending = nil
 self.worker = self.worker or CreateFrame('Frame')
 self.worker:SetScript('OnUpdate',function(_,dt)
  PF.elapsed = PF.elapsed + dt
  if PF.elapsed < PF.db.openDelay then return end
  PF.elapsed = 0
  PF:ProcessNext()
 end)
 self:Print(selectedOnly and 'Collecting selected mail...' or 'Collecting all eligible mail...')
end
function PF:ProcessNext()
 if not self.mailOpen then self:Stop(nil); return end
 local count = self:Count()
 if self.cursor > count then self.cursor = count end
 local attempts = 0
 while self.cursor >= 1 and attempts < 60 do
  attempts = attempts + 1
  local index = self.cursor
  local h = self:Header(index)
  if not h then self.cursor = self.cursor - 1
  elseif self.selectedOnly and not self.db.selected[index] then self.cursor = self.cursor - 1
  elseif (tonumber(h.cod) or 0) > 0 then self.cursor = self.cursor - 1
  else
   local money = tonumber(h.money) or 0
   local items = tonumber(h.items) or 0
   if money > 0 then
    local ok = invoke(M.TakeInboxMoney or TakeInboxMoney,index)
    if not ok then self:Stop('Could not take money'); return end
    self:Record('Receive gold',h.sender,tostring(money)..' copper')
    return
   end
   if items > 0 then
    local itemInfo = M.GetInboxItem or GetInboxItem
    if type(itemInfo) == 'function' then
     for slot = 1, math.min(items, 16) do
      local ok, a = pcall(itemInfo,index,slot)
      if ok and a ~= nil then
       local taken = invoke(M.TakeInboxItem or TakeInboxItem,index,slot)
       if taken then self:Record('Receive item',h.sender,h.subject); return end
      end
     end
    end
    self.cursor = self.cursor - 1
   else self.cursor = self.cursor - 1 end
  end
 end
 if self.cursor < 1 then self:Stop('Collection complete (COD mail skipped).') end
end
function PF:OnInboxUpdate()
 -- The mailbox can reorder messages as they are emptied. Restart from the end
 -- after updates to avoid stale indices; a finite timeout prevents endless loops.
 if self.running then
  self.updates = (self.updates or 0) + 1
  if self.updates > 1500 then self:Stop('Safety limit reached'); return end
  self.cursor = self:Count()
 end
end
function PF:ReturnSelected()
 if not self.mailOpen then return end
 local fn = M.ReturnInboxItem or ReturnInboxItem
 if type(fn) ~= 'function' then self:Print('Return API unavailable'); return end
 for i=self:Count(),1,-1 do
  if self.db.selected[i] then
   local h = self:Header(i)
   if h and (tonumber(h.cod) or 0) == 0 then
    local ok = invoke(fn,i)
    if ok then self:Record('Return',h.sender,h.subject); self.db.selected[i] = nil; self:RefreshUI(); return end
   end
  end
 end
 self:Print('No eligible selected message to return.')
end
function PF:DeleteSelected()
 if not self.mailOpen then return end
 local fn = M.DeleteInboxItem or DeleteInboxItem
 if type(fn) ~= 'function' then self:Print('Delete API unavailable'); return end
 for i=self:Count(),1,-1 do
  if self.db.selected[i] then
   local h = self:Header(i)
   if h and (tonumber(h.money) or 0) == 0 and (tonumber(h.items) or 0) == 0 then
    if invoke(fn,i) then self:Record('Delete',h.sender,h.subject); self.db.selected[i] = nil; self:RefreshUI(); return end
   end
  end
 end
 self:Print('Select an empty message to delete.')
end
function PF:OnSendSuccess()
 local recipient = self:DisplayName(self.lastRecipient)
 if recipient then
  self:AddContact(recipient)
  self:Record('Sent', recipient, self.lastSubject or '')
  -- A successful send is stronger evidence than a popup click: it confirms
  -- that the game accepted this exact recipient. Remember it for future use.
  -- This is an address-book trust flag, NOT permission to bypass server dialogs.
  if not self:IsTrustedRecipient(recipient) then
   self:TrustName(recipient, true)
   self:Print('Added to Trusted Recipients: '..recipient)
  end
 end
 self.pendingTrustedRecipient = nil
 self.lastRecipient = nil
 self.lastSubject = nil
end
