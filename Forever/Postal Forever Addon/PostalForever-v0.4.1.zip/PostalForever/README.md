# PostalForever v0.4.0 (Beta)

Combines PostalForever v0.3.4 and the mail notification behavior and MP3 supplied in YouveGotMailForever v1.1.1.

## New: You've Got Mail
- Plays the bundled notification on login when the game reports pending mail.
- Plays for newly detected mail; avoids repeating the sound until mail status clears.
- `/pf mailalert on` / `/pf mailalert off` / `/pf mailalert status` / `/pf mailalert test`.
- Enabled by default. Settings persist in PostalForeverDB.
- Uses `HasNewMail()` where available and the minimap mail icon as a fallback.

## Installation
Extract the `PostalForever` folder to your Forever `Interface/AddOns` directory. Replace the previous version, retaining saved variables. Disable or remove the standalone `YouveGotMailForever` addon to avoid duplicate sounds.

## Notes
The notification depends on client mail events and pending-mail indicators. If the game does not expose them reliably, detection may need client-specific adjustments. Sound playback and the new commands have not been tested inside WoW Forever. Existing PostalForever features are retained from v0.3.4.


## v0.4.1 Trusted Recipients update
- Every successful send now adds the recipient to Trusted Recipients automatically.
- Account Alts are treated as trusted within PostalForever, without needing to send mail first.
- Existing trusted names remain saved across logins.
- The native WoW Forever mail confirmation is controlled by the game/server and may still appear. PostalForever does not bypass it.
- If the server presents a warning on every send, that behavior cannot be disabled by the saved recipient list alone.
