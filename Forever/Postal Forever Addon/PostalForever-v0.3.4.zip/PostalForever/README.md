# PostalForever v0.3.4 (beta)

## Changes
- Trusted Recipients list in the To: dropdown. Hover a trusted name to select it or remove trust.
- `/pf trusted`, `/pf trust First-Last`, `/pf untrust First-Last`.
- Automatic trust registration is conservative: it only attempts to recognize a native mailing warning when the popup identifier is mail-related **and** its text contains the exact recipient; the send must then succeed. Forever's popup identifiers have not been verified, so this may not trigger until tested.
- The To: dropdown now opens on an actual left-click in the visible Send Mail recipient field, not on focus while the Inbox opens.
- Trusted recipients remain separate from Account Alts and Recently Mailed.

## Install
Exit WoW, back up PostalForeverDB saved variables, and replace Interface/AddOns/PostalForever with this folder.

## Test
1. Open mailbox on Inbox tab: recipient dropdown should remain closed.
2. Switch to Send Mail and click To:: recipient dropdown should appear.
3. Use `/pf trust Slan-Suran` and `/pf trusted` to verify manual storage.
4. Confirm a native mailing warning and send low-value mail. If the trusted list is not updated, the popup format needs to be identified in Forever; no warnings are bypassed.

This release has not been tested in the Forever client.
