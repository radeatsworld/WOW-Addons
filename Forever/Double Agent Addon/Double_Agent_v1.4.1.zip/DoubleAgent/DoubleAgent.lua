-- Double Agent 1.4.1 - legacy Lua 5.1 compatible
local prefix = '|cff9bc6ffDouble Agent|r: '
local function notice(s)
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(prefix .. tostring(s)) end
end
local function dictionary()
  local race, raceToken = UnitRace('player')
  local faction = UnitFactionGroup('player')
  if faction == 'Alliance' then return DOUBLEAGENT_COMMON, 'Common' end
  if raceToken == 'Scourge' or race == 'Undead' or race == 'Forsaken' then return DOUBLEAGENT_UNDEAD, 'Gutterspeak' end
  if raceToken == 'Troll' then return DOUBLEAGENT_ZANDALI, 'Zandali' end
  if raceToken == 'Tauren' then return DOUBLEAGENT_TAURAHE, 'Taurahe' end
  if raceToken == 'BloodElf' or race == 'Blood Elf' then return DOUBLEAGENT_THALASSIAN, 'Thalassian' end
  if faction == 'Horde' then return DOUBLEAGENT_ORCISH, 'Orcish' end
  return nil, nil
end
local function translate(message, dict)
  local input = string.upper(message or '')
  local outgoing, expected = {}, {}
  local alpha = dict.ALPHABET or {}
  local subs = dict.SUBSTITUTES or {}
  local sep = dict.SEPARATOR or {INPUT=' ', OUTPUT=' '}
  local steps = 0
  while #input > 0 and steps < 4096 do
    steps = steps + 1
    local matched = false
    for _, pair in ipairs(alpha) do
      local k, v = pair[1], pair[2]
      if string.sub(input, 1, #k) == k then
        table.insert(outgoing, v)
        table.insert(expected, k)
        input = string.sub(input, #k + 1)
        matched = true
        break
      end
    end
    if not matched then
      local ch = string.sub(input, 1, 1)
      local replacement = subs[ch]
      if replacement then
        input = replacement .. string.sub(input, 2)
        matched = true
      elseif string.find(ch, '%s') then
        table.insert(outgoing, sep.INPUT)
        table.insert(expected, sep.OUTPUT)
        input = string.sub(input, 2)
        matched = true
      end
    end
    if not matched then input = string.sub(input, 2) end
  end
  return table.concat(outgoing, ' '), table.concat(expected, ' ')
end
local function send(message, channel)
  if not message or not string.find(message, '%S') then
    notice('Usage: /da message, /day message, /dapreview message, /dahelp')
    return
  end
  local dict, language = dictionary()
  if not dict then notice('Unable to identify a supported character language.'); return end
  local encoded, preview = translate(message, dict)
  if encoded == '' then notice('No translatable letters found.'); return end
  -- Legacy chat clients and private servers may impose different message limits.
  if #encoded > 210 then notice('Encoded message is too long (' .. #encoded .. ' bytes; limit 210).'); return end
  notice('Language: ' .. language .. ' | Intended reading: ' .. preview)
  if channel == 'PREVIEW' then return end
  local fn = SendChatMessage
  if not fn and C_ChatInfo then fn = C_ChatInfo.SendChatMessage end
  if not fn then notice('Chat sending API unavailable.'); return end
  local ok, err = pcall(fn, encoded, channel, dict.LanguageID)
  if not ok then notice('Chat send failed: ' .. tostring(err)) end
end
SLASH_DOUBLEAGENT1 = '/da'
SLASH_DOUBLEAGENT2 = '/doubleagent'
SlashCmdList['DOUBLEAGENT'] = function(msg) send(msg, 'SAY') end

SLASH_DOUBLEAGENTYELL1 = '/day'
SlashCmdList['DOUBLEAGENTYELL'] = function(msg) send(msg, 'YELL') end

SLASH_DOUBLEAGENTPREVIEW1 = '/dapreview'
SlashCmdList['DOUBLEAGENTPREVIEW'] = function(msg) send(msg, 'PREVIEW') end

SLASH_DOUBLEAGENTHELP1 = '/dahelp'
SlashCmdList['DOUBLEAGENTHELP'] = function()
  notice('/da <message> - Say | /day <message> - Yell | /dapreview <message> - Preview only')
  notice('/doubleagent <message> - Say | /dahelp - Help. Server language restrictions apply.')
end
