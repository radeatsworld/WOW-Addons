Double Agent v1.4.1 — WoW Forever

Install the DoubleAgent folder into Interface\AddOns and restart the game.

Commands:
/da <message>          Send encoded text to Say
/doubleagent <message> Same as /ft
/day <message>         Send encoded text to Yell
/dapreview <message>   Preview encoding without sending
/dahelp                Show help

All addon code and translation tables are loaded from this folder. No external addon, library, remote endpoint, or downloaded file is required. WoW's built-in APIs are used for chat, race detection, and the chat window.

Cross-faction readability depends on server language rules and supported characters. This build is not verified in the live client. Some language dictionaries are based on the source archive supplied for adaptation; this package does not assert exclusive authorship of that source material.
