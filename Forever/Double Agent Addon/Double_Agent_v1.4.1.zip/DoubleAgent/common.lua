DOUBLEAGENT_COMMON = {
	LanguageID = 7,
	ALPHABET = {
		{ 'A', '€' },
		{ 'B', '῁' },
		{ 'D', '🵐' },
		{ 'E', '4' },
		{ 'F', 'Ἆ' },
		{ 'G', '🟰' },
		{ 'H', '༫' },
		{ 'I', '0' },
		{ 'K', 'Š' },
		{ 'L', 'ⶎ' },
		{ 'M', 'Ä' },
		{ 'N', '🤭' },
		{ 'O', '6' },
		{ 'R', '‡' },
		{ 'S', 'Ğ' },
		{ 'T', '🻂' },
		{ 'U', '򧏭' },
		{ 'V', 'Ё' },
		{ 'W', 'Ἠ' },
		{ 'Y', '3' }
	},

	SUBSTITUTES = {
		C = 'K',
		J = 'G',
		P = 'B',
		Q = 'K',
		X = 'KS',
		Z = 'S'
	},

	SEPARATOR = { 
		INPUT = 'à',
		OUTPUT = 'r'
	}
}