-- Hide Known 1.0.0 - legacy 1.12-style client
local addon = CreateFrame('Frame', 'HideKnownFrame')
local original = {}
local db
local function enabled(key) return db and db.enabled and db[key] end
local function status(msg) DEFAULT_CHAT_FRAME:AddMessage('|cff33ccffHide Known:|r '..msg) end
local function setTrainerFilter()
  if not enabled('trainer') or not SetTrainerServiceTypeFilter then return end
  -- The trainer API provides a built-in filter for already-known spells.
  SetTrainerServiceTypeFilter('available', 1)
  SetTrainerServiceTypeFilter('unavailable', 1)
  SetTrainerServiceTypeFilter('used', 0)
  if TrainerFrame_Update then TrainerFrame_Update() end
end
local function restoreTrainerFilter()
  if not SetTrainerServiceTypeFilter then return end
  SetTrainerServiceTypeFilter('used', 1)
  if TrainerFrame_Update then TrainerFrame_Update() end
end
local function setPetFilter()
  if not enabled('pet') or not SetPetTrainerServiceTypeFilter then return end
  SetPetTrainerServiceTypeFilter('available', 1)
  SetPetTrainerServiceTypeFilter('unavailable', 1)
  SetPetTrainerServiceTypeFilter('used', 0)
  if PetTrainerFrame_Update then PetTrainerFrame_Update() end
end
local function restorePetFilter()
  if SetPetTrainerServiceTypeFilter then
    SetPetTrainerServiceTypeFilter('used', 1)
    if PetTrainerFrame_Update then PetTrainerFrame_Update() end
  end
end
local function hook(name, callback)
  local old = getglobal(name)
  if type(old) ~= 'function' then return end
  original[name] = old
  setglobal(name, function(...)
    local a,b,c,d,e = old(unpack(arg))
    callback()
    return a,b,c,d,e
  end)
end
local guard = false
local function refreshTrainer()
  if guard then return end
  guard = true
  if enabled('trainer') then setTrainerFilter() end
  guard = false
end
local function refreshPet()
  if guard then return end
  guard = true
  if enabled('pet') then setPetFilter() end
  guard = false
end
local function makeToggle(frameName, label, key, onChange)
  local parent = getglobal(frameName)
  if not parent then return end
  local c = CreateFrame('CheckButton', 'HideKnown'..key..'Toggle', parent, 'UICheckButtonTemplate')
  c:SetWidth(24); c:SetHeight(24)
  c:SetPoint('TOPRIGHT', parent, 'TOPRIGHT', -35, -28)
  local txt = getglobal(c:GetName()..'Text')
  if txt then txt:SetText(label); txt:ClearAllPoints(); txt:SetPoint('RIGHT', c, 'LEFT', -3, 0) end
  c:SetScript('OnClick', function()
    db[key] = not this:GetChecked()
    onChange()
  end)
  c:SetScript('OnShow', function() this:SetChecked(not db[key]) end)
end
local function initialize()
  if not HideKnownDB then HideKnownDB = {} end
  db = HideKnownDB
  if db.enabled == nil then db.enabled = true end
  if db.trainer == nil then db.trainer = true end
  if db.pet == nil then db.pet = true end
  if db.vendor == nil then db.vendor = true end
  hook('TrainerFrame_Update', refreshTrainer)
  hook('PetTrainerFrame_Update', refreshPet)
  makeToggle('TrainerFrame', 'Show known', 'trainer', function() if db.trainer then setTrainerFilter() else restoreTrainerFilter() end end)
  makeToggle('PetTrainerFrame', 'Show known', 'pet', function() if db.pet then setPetFilter() else restorePetFilter() end end)
  SLASH_HIDEKNOWN1 = '/hideknown'
  SLASH_HIDEKNOWN2 = '/hk'
  SlashCmdList['HIDEKNOWN'] = function(msg)
    msg = string.lower(msg or '')
    if msg == 'on' then db.enabled=true; setTrainerFilter(); setPetFilter(); status('enabled')
    elseif msg == 'off' then db.enabled=false; restoreTrainerFilter(); restorePetFilter(); status('disabled')
    elseif msg == 'trainer' then db.trainer=not db.trainer; if db.trainer then setTrainerFilter() else restoreTrainerFilter() end; status('trainer filter '..(db.trainer and 'on' or 'off'))
    elseif msg == 'pet' then db.pet=not db.pet; if db.pet then setPetFilter() else restorePetFilter() end; status('pet trainer filter '..(db.pet and 'on' or 'off'))
    else status('Commands: /hk on, off, trainer, pet') end
  end
end
addon:RegisterEvent('VARIABLES_LOADED')
addon:RegisterEvent('TRAINER_SHOW')
addon:RegisterEvent('PET_TRAINER_SHOW')
addon:SetScript('OnEvent', function()
  if event == 'VARIABLES_LOADED' then initialize()
  elseif event == 'TRAINER_SHOW' then refreshTrainer()
  elseif event == 'PET_TRAINER_SHOW' then refreshPet() end
end)
