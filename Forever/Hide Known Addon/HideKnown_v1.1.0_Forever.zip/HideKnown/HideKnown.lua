-- Hide Known 1.1.0 - WoW Forever (modern API)
local addon = CreateFrame('Frame')
local db
local function say(s) print('|cff33ccffHide Known:|r '..s) end
local function active(key) return db and db.enabled and db[key] end
local function filterTrainer()
  if not C_Trainer or not C_Trainer.SetFilter then return end
  -- Trainer service types are defined by the client; use constants when present.
  local known = Enum and Enum.TrainerServiceType and Enum.TrainerServiceType.Used
  if known ~= nil then
    C_Trainer.SetFilter(known, not active('trainer'))
  end
end
local function legacyTrainer()
  if type(SetTrainerServiceTypeFilter) == 'function' then
    SetTrainerServiceTypeFilter('used', not active('trainer'))
  end
end
local function refresh()
  if type(TrainerFrame_Update) == 'function' then TrainerFrame_Update() end
end
local function apply()
  filterTrainer()
  legacyTrainer()
  refresh()
end
local function toggleUI(parent, key, x, y)
  if not parent then return end
  local cb = CreateFrame('CheckButton', nil, parent, 'UICheckButtonTemplate')
  cb:SetSize(24,24)
  cb:SetPoint('TOPRIGHT', parent, 'TOPRIGHT', x, y)
  local t = cb:CreateFontString(nil, 'OVERLAY', 'GameFontNormalSmall')
  t:SetPoint('RIGHT', cb, 'LEFT', -3, 0)
  t:SetText('Show known')
  cb:SetScript('OnShow', function(self) self:SetChecked(not active(key)) end)
  cb:SetScript('OnClick', function(self)
    db[key] = not self:GetChecked()
    apply()
  end)
  cb:SetChecked(not active(key))
end
local function init()
  HideKnownDB = HideKnownDB or {}
  db = HideKnownDB
  if db.enabled == nil then db.enabled = true end
  if db.trainer == nil then db.trainer = true end
  if db.pet == nil then db.pet = true end
  if db.vendor == nil then db.vendor = false end
  -- Modern trainers may be loaded on demand; register once the UI becomes available.
  if type(TrainerFrame) == 'table' then toggleUI(TrainerFrame, 'trainer', -35, -28) end
  if type(PetTrainerFrame) == 'table' then toggleUI(PetTrainerFrame, 'pet', -35, -28) end
  apply()
end
SLASH_HIDEKNOWN1 = '/hk'
SLASH_HIDEKNOWN2 = '/hideknown'
SlashCmdList.HIDEKNOWN = function(msg)
  if not db then return end
  msg = (msg or ''):lower():match('^%s*(.-)%s*$')
  if msg == 'on' then db.enabled = true
  elseif msg == 'off' then db.enabled = false
  elseif msg == 'trainer' then db.trainer = not db.trainer
  elseif msg == 'pet' then db.pet = not db.pet
  elseif msg == 'status' or msg == '' then
    say('enabled='..tostring(db.enabled)..', trainer='..tostring(db.trainer)..', pet='..tostring(db.pet))
    say('Commands: /hk on, off, trainer, pet, status')
    return
  else say('Commands: /hk on, off, trainer, pet, status'); return end
  apply()
  say('Settings updated.')
end
addon:RegisterEvent('ADDON_LOADED')
addon:RegisterEvent('TRAINER_SHOW')
addon:RegisterEvent('PET_TRAINER_SHOW')
addon:SetScript('OnEvent', function(self, event, name)
  if event == 'ADDON_LOADED' and name == 'HideKnown' then init()
  elseif event == 'TRAINER_SHOW' or event == 'PET_TRAINER_SHOW' then apply() end
end)
