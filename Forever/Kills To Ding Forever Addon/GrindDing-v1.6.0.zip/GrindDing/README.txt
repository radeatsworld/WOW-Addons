Grind Ding v1.6.0 for WoW Forever

NEW: XP/hour and Time to ding in the expanded tracker.
XP/hour is based on all earned XP since login or the last timer reset, divided by real elapsed time. Includes quests and kill XP. Idle time reduces the hourly rate. Time to ding = Remaining XP / XP per hour.
/gd timer reset: restart XP/hour measurement without clearing kill averages.
/gd reset: clear kill averages only.

Other commands: /gd show, hide, minimize, maximize, size 245-520, levels, range 0-10, samples 1-50, center.
Old /ktd and /ktl aliases remain available.

Install: close game, replace GrindDing folder in Interface/AddOns, restart.
In-game testing required. Timer is session-only and starts at login. The first rate may fluctuate substantially.
