-- Kills To Ding Forever v1.4.0 (WoW Forever interface 16001)
local frame = CreateFrame('Frame')
local db, panel, mini, priorLevel
local MAX_SAMPLES = 50
local lastTargetName, lastTargetLevel, lastTargetAt
local function notice(s) print('|cffd8b45aKills To Ding Forever:|r '..s) end
local function clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end
local function init()
  if type(KillsToDingForeverDB) ~= 'table' then KillsToDingForeverDB = {} end
  db = KillsToDingForeverDB
  if type(db.samples) ~= 'table' then db.samples = {} end
  if type(db.byLevel) ~= 'table' then db.byLevel = {} end
  db.sampleSize = clamp(tonumber(db.sampleSize) or 20, 1, MAX_SAMPLES)
  db.range = clamp(tonumber(db.range) or 5, 0, 10)
  if db.visible == nil then db.visible = true end
  if db.levelsVisible == nil then db.levelsVisible = true end
  if db.collapsed == nil then db.collapsed = false end
  db.windowWidth = clamp(tonumber(db.windowWidth) or 285, 245, 520)
  db.extraHeight = clamp(tonumber(db.extraHeight) or 0, 0, 240)
end
local function avg(values)
  if not values or #values == 0 then return nil, 0 end
  local sum = 0
  for _, v in ipairs(values) do sum = sum + v end
  return sum / #values, #values
end
local function push(values, xp)
  table.insert(values, xp)
  while #values > db.sampleSize do table.remove(values, 1) end
end
local function rememberTarget()
  if not UnitExists('target') or UnitIsPlayer('target') or not UnitCanAttack('player','target') then return end
  local level = UnitLevel('target')
  if not level or level < 1 then return end -- Boss/unknown levels are not attributed.
  lastTargetName, lastTargetLevel, lastTargetAt = UnitName('target'), level, GetTime()
end
local function addKill(xp, name)
  if not xp or xp <= 0 then return end
  push(db.samples, xp)
  -- Attribution is deliberately conservative: recent matching target only.
  if name and lastTargetName and name == lastTargetName and GetTime() - (lastTargetAt or 0) <= 12 then
    local key = tostring(lastTargetLevel)
    if type(db.byLevel[key]) ~= 'table' then db.byLevel[key] = {} end
    push(db.byLevel[key], xp)
  end
end
local function parseKill(message)
  if type(message) ~= 'string' then return end
  -- Only kill-specific English messages, not quests, exploration or generic XP.
  local name, xp = message:match('^(.+) dies, you gain ([%d,]+) experience')
  if not xp then name, xp = message:match('^(.+) dies, you gain ([%d,]+) XP') end
  if not xp then return end
  return tonumber((xp:gsub(',', ''))), name
end
local function estimate(level, playerLevel, globalAvg)
  local measured, count = avg(db.byLevel[tostring(level)])
  if measured then return measured, count, true end
  if not globalAvg then return nil, 0, false end
  -- Heuristic fallback, NOT the server's XP formula. Calibrate from the
  -- weighted center of known level-specific samples where possible.
  local weighted, n = 0, 0
  for key, values in pairs(db.byLevel) do
    local lv = tonumber(key)
    if lv and #values > 0 then weighted = weighted + lv * #values; n = n + #values end
  end
  local center = n > 0 and weighted/n or playerLevel
  -- 5% per enemy-level difference, capped to avoid extreme extrapolation.
  return globalAvg * clamp(1 + (level-center)*0.05, 0.25, 2), 0, false
end
local layoutPanel
local function refresh()
  if not panel then return end
  local current, maxXP, level = UnitXP('player') or 0, UnitXPMax('player') or 0, UnitLevel('player') or 1
  local remaining = math.max(0, maxXP-current)
  local overall, count = avg(db.samples)
  local kills = overall and math.ceil(remaining/overall) or nil
  panel.title:SetText('Kills To Ding Forever')
  panel.currentLevel:SetText(string.format('Current Level %d', level))
  panel.xpLabel:SetText(string.format('XP: %d / %d', current, maxXP))
  panel.remainingXP:SetText(string.format('Remaining XP: %d', remaining))
  panel.killsToDing:SetText('Kills to ding: '..(kills and tostring(kills) or '--'))
  -- Separate FontStrings keep all columns aligned regardless of proportional font widths.
  local rowCount = 0
  if db.levelsVisible then
    for enemy = math.max(1, level-db.range), level+db.range do
      rowCount = rowCount + 1
      local row = panel.levelRows[rowCount]
      if not row then
        row = {}
        for _, column in ipairs({'enemy','xp','kills'}) do
          local label = panel:CreateFontString(nil, 'OVERLAY', 'GameFontHighlightSmall')
          label:SetJustifyH(column == 'enemy' and 'LEFT' or 'RIGHT')
          row[column] = label
        end
        -- Positions are assigned by layoutPanel() after data is populated.
        panel.levelRows[rowCount] = row
      end
      local xp, n, measured = estimate(enemy, level, overall)
      local xpText = xp and string.format('%.0f', xp) or '--'
      local countText = xp and xp > 0 and tostring(math.ceil(remaining/xp)) or '--'
      local difference = enemy - level
      local r, g, b
      if difference <= 0 then r,g,b = 0.30,1.00,0.45
      elseif difference <= 2 then r,g,b = 1.00,0.88,0.20
      else r,g,b = 1.00,0.32,0.32 end
      row.enemy:SetText(tostring(enemy))
      row.xp:SetText(xpText)
      row.kills:SetText(countText)
      for _, column in ipairs({'enemy','xp','kills'}) do
        row[column]:SetFontObject(difference == 0 and 'GameFontNormal' or 'GameFontHighlightSmall')
        row[column]:SetTextColor(r,g,b)
        row[column]:Show()
      end
    end
  end
  for i = rowCount+1, #panel.levelRows do
    local row = panel.levelRows[i]
    row.enemy:Hide(); row.xp:Hide(); row.kills:Hide()
  end
  panel.levelHeader:SetShown(db.levelsVisible)
  panel.levelHeaderXP:SetShown(db.levelsVisible)
  panel.levelHeaderKills:SetShown(db.levelsVisible)
  panel.levelFoot:SetShown(db.levelsVisible)
  layoutPanel(rowCount)
end
local function applyVisibility()
  if not panel or not mini then return end
  if not db.visible then panel:Hide(); mini:Hide()
  elseif db.collapsed then panel:Hide(); mini:Show()
  else mini:Hide(); panel:Show() end
end
local function setCollapsed(value)
  db.collapsed = value and true or false
  applyVisibility()
end
local function savePosition(self)
  self:StopMovingOrSizing()
  local p,_,rp,x,y = self:GetPoint(1)
  db.point,db.relativePoint,db.x,db.y = p,rp,x,y
  -- Both frames share a saved anchor, so moving either moves the other.
  local other = self == panel and mini or panel
  if other then
    other:ClearAllPoints()
    other:SetPoint(p, UIParent, rp, x, y)
  end
end
-- All coordinates derive from the current width. Text fields have bounded widths,
-- so large XP totals wrap instead of drawing over the next field.
layoutPanel = function(rowCount)
  if not panel then return end
  local w = db.windowWidth
  panel:SetWidth(w)
  local margin = 15
  local usable = w - margin * 2
  local gap = 16
  local fontSize = clamp(math.floor(w / 28), 10, 13)
  local fontPath = STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF'
  local labels = {panel.currentLevel, panel.xpLabel, panel.remainingXP, panel.killsToDing}
  for _, label in ipairs(labels) do label:SetFont(fontPath, fontSize, '') end
  panel.title:SetWidth(w-58)
  panel.title:SetFont(fontPath, clamp(fontSize+1, 11, 15), 'OUTLINE')
  panel.title:ClearAllPoints()
  panel.title:SetPoint('TOPLEFT', panel, 'TOPLEFT', margin, -12)
  panel.currentLevel:SetWidth(usable)
  -- Split the XP line only when the text cannot fit in the available width.
  local xpWidth = panel.xpLabel:GetStringWidth() + 3
  local remainWidth = panel.remainingXP:GetStringWidth() + 3
  local split = xpWidth + gap + remainWidth > usable
  local xpY = -53
  panel.xpLabel:ClearAllPoints()
  panel.xpLabel:SetPoint('TOPLEFT', panel, 'TOPLEFT', margin, xpY)
  panel.xpLabel:SetWidth(split and usable or xpWidth)
  panel.remainingXP:ClearAllPoints()
  if split then
    panel.remainingXP:SetPoint('TOPLEFT', panel, 'TOPLEFT', margin, xpY-19)
    panel.remainingXP:SetWidth(usable)
  else
    panel.remainingXP:SetPoint('TOPLEFT', panel.xpLabel, 'TOPRIGHT', gap, 0)
    panel.remainingXP:SetWidth(usable-xpWidth-gap)
  end
  local shift = split and 19 or 0
  panel.killsToDing:ClearAllPoints()
  panel.killsToDing:SetPoint('TOPLEFT', panel, 'TOPLEFT', margin, -72-shift)
  panel.killsToDing:SetWidth(usable)
  local tableTop = -105-shift
  local leftWidth = math.floor(usable * 0.36)
  local middleWidth = math.floor(usable * 0.34)
  local rightWidth = usable-leftWidth-middleWidth
  local columns = {
    {x=margin, width=leftWidth},
    {x=margin+leftWidth, width=middleWidth},
    {x=margin+leftWidth+middleWidth, width=rightWidth},
  }
  local headers = {panel.levelHeader, panel.levelHeaderXP, panel.levelHeaderKills}
  for i, header in ipairs(headers) do
    header:ClearAllPoints()
    header:SetPoint('TOPLEFT',panel,'TOPLEFT',columns[i].x,tableTop)
    header:SetWidth(columns[i].width)
  end
  local rowHeight = 15
  for index, row in ipairs(panel.levelRows) do
    for i, key in ipairs({'enemy','xp','kills'}) do
      local label = row[key]
      label:ClearAllPoints()
      label:SetPoint('TOPLEFT',panel,'TOPLEFT',columns[i].x,tableTop-20-(index-1)*rowHeight)
      label:SetWidth(columns[i].width)
    end
  end
  panel.levelFoot:ClearAllPoints()
  panel.levelFoot:SetPoint('TOPLEFT',panel,'TOPLEFT',margin,tableTop-20-rowCount*rowHeight-5)
  panel.levelFoot:SetWidth(usable)
  local required = db.levelsVisible and (-tableTop+20+rowCount*rowHeight+32) or (112+shift)
  panel:SetHeight(required + db.extraHeight)
end

local function makePanel()
  panel = CreateFrame('Frame','KillsToDingForeverFrame',UIParent,'BackdropTemplate')
  panel:SetSize(db.windowWidth, 285)
  panel:SetClampedToScreen(true)
  panel:SetMovable(true)
  panel:EnableMouse(true)
  panel:RegisterForDrag('LeftButton')
  panel:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=12,insets={left=3,right=3,top=3,bottom=3}})
  panel:SetPoint(db.point or 'CENTER', UIParent, db.relativePoint or 'CENTER', db.x or 0, db.y or 0)
  panel:SetScript('OnDragStart',function(self) self:StartMoving() end)
  panel:SetScript('OnDragStop',savePosition)
  panel.title = panel:CreateFontString(nil,'OVERLAY','GameFontNormal')
  panel.title:SetPoint('TOP',0,-12)
  -- Independent header labels avoid tab characters and proportional-font drift.
  panel.currentLevel = panel:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  panel.currentLevel:SetPoint('TOPLEFT',panel,'TOPLEFT',14,-34)
  panel.currentLevel:SetJustifyH('LEFT')
  panel.xpLabel = panel:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  panel.xpLabel:SetPoint('TOPLEFT',panel,'TOPLEFT',14,-51)
  panel.xpLabel:SetJustifyH('LEFT')
  panel.remainingXP = panel:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  -- A compact one-tab-like 16px gap from the end of the XP text.
  panel.remainingXP:SetPoint('LEFT',panel.xpLabel,'RIGHT',16,0)
  panel.remainingXP:SetJustifyH('LEFT')
  panel.killsToDing = panel:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  panel.killsToDing:SetPoint('TOPLEFT',panel,'TOPLEFT',14,-68)
  panel.killsToDing:SetJustifyH('LEFT')
  panel.levelRows = {}
  panel.levelHeader = panel:CreateFontString(nil,'OVERLAY','GameFontNormalSmall')
  panel.levelHeader:SetPoint('TOPLEFT',panel,'TOPLEFT',21,-100)
  panel.levelHeader:SetText('Enemy Lv')
  panel.levelHeaderXP = panel:CreateFontString(nil,'OVERLAY','GameFontNormalSmall')
  panel.levelHeaderXP:SetPoint('TOPLEFT',panel,'TOPLEFT',93,-100)
  panel.levelHeaderXP:SetWidth(58)
  panel.levelHeaderXP:SetJustifyH('RIGHT')
  panel.levelHeaderXP:SetText('XP/kill')
  panel.levelHeaderKills = panel:CreateFontString(nil,'OVERLAY','GameFontNormalSmall')
  panel.levelHeaderKills:SetPoint('TOPLEFT',panel,'TOPLEFT',170,-100)
  panel.levelHeaderKills:SetWidth(49)
  panel.levelHeaderKills:SetJustifyH('RIGHT')
  panel.levelHeaderKills:SetText('Kills')
  panel.levelFoot = panel:CreateFontString(nil,'OVERLAY','GameFontHighlightSmall')
  panel.levelFoot:SetText('~ values')
  panel.levelFoot:SetTextColor(0.7,0.7,0.7)
  panel.levelFoot:SetJustifyH('LEFT')
  -- Minimize control on the full window.
  local collapse = CreateFrame('Button', nil, panel, 'UIPanelButtonTemplate')
  collapse:SetSize(20, 19)
  collapse:SetPoint('TOPRIGHT', panel, 'TOPRIGHT', -6, -7)
  collapse:SetText('-')
  collapse:SetScript('OnClick', function() setCollapsed(true) end)
  collapse:SetFrameLevel(panel:GetFrameLevel()+2)
  -- Drag the lower-right handle to resize. Height has a content-safe minimum.
  local grip = CreateFrame('Button', nil, panel)
  grip:SetSize(19, 19)
  grip:SetPoint('BOTTOMRIGHT', panel, 'BOTTOMRIGHT', -3, 3)
  grip:SetFrameLevel(panel:GetFrameLevel()+3)
  local gripText = grip:CreateFontString(nil, 'OVERLAY', 'GameFontNormal')
  gripText:SetPoint('CENTER', grip, 'CENTER', 0, 0)
  gripText:SetText('\\')
  grip:SetScript('OnMouseDown', function(self, button)
    if button ~= 'LeftButton' then return end
    self.dragging = true
    self.startX, self.startY = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale()
    self.startX, self.startY = self.startX/scale, self.startY/scale
    self.startWidth, self.startHeight = db.windowWidth, db.extraHeight
  end)
  grip:SetScript('OnMouseUp', function(self) self.dragging = false end)
  grip:SetScript('OnHide', function(self) self.dragging = false end)
  grip:SetScript('OnUpdate', function(self)
    if not self.dragging then return end
    local x, y = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale()
    x, y = x/scale, y/scale
    local newWidth = clamp(math.floor(self.startWidth+x-self.startX),245,520)
    local newExtra = clamp(math.floor(self.startHeight+self.startY-y),0,240)
    if newWidth ~= db.windowWidth or newExtra ~= db.extraHeight then
      db.windowWidth, db.extraHeight = newWidth, newExtra
      refresh()
    end
  end)

  -- Separate draggable collapsed bar, anchored to the same screen location.
  mini = CreateFrame('Frame', 'KillsToDingForeverMiniFrame', UIParent, 'BackdropTemplate')
  mini:SetSize(115, 29)
  mini:SetClampedToScreen(true)
  mini:SetMovable(true)
  mini:EnableMouse(true)
  mini:RegisterForDrag('LeftButton')
  mini:SetBackdrop({bgFile='Interface\\DialogFrame\\UI-DialogBox-Background',edgeFile='Interface\\Tooltips\\UI-Tooltip-Border',edgeSize=12,insets={left=3,right=3,top=3,bottom=3}})
  mini:SetPoint(db.point or 'CENTER', UIParent, db.relativePoint or 'CENTER', db.x or 0, db.y or 0)
  mini:SetScript('OnDragStart', function(self) self:StartMoving() end)
  mini:SetScript('OnDragStop', savePosition)
  local name = mini:CreateFontString(nil,'OVERLAY','GameFontNormal')
  name:SetPoint('LEFT', mini, 'LEFT', 12, 0)
  name:SetText('KTDF')
  local expand = CreateFrame('Button', nil, mini, 'UIPanelButtonTemplate')
  expand:SetSize(23, 20)
  expand:SetPoint('RIGHT', mini, 'RIGHT', -6, 0)
  expand:SetText('+')
  expand:SetScript('OnClick', function() setCollapsed(false) end)
  expand:SetFrameLevel(mini:GetFrameLevel()+2)
  applyVisibility()
  refresh()
end
frame:RegisterEvent('PLAYER_LOGIN')
frame:RegisterEvent('PLAYER_XP_UPDATE')
frame:RegisterEvent('PLAYER_LEVEL_UP')
frame:RegisterEvent('PLAYER_TARGET_CHANGED')
frame:RegisterEvent('UNIT_LEVEL')
frame:RegisterEvent('CHAT_MSG_COMBAT_XP_GAIN')
frame:SetScript('OnEvent',function(_, event, ...)
  if event == 'PLAYER_LOGIN' then
    init()
    priorLevel = UnitLevel('player')
    makePanel()
    notice('Loaded. /ktd for commands.')
  elseif not db then return
  elseif event == 'PLAYER_TARGET_CHANGED' then rememberTarget()
  elseif event == 'UNIT_LEVEL' then
    if (...) == 'target' then rememberTarget() end
  elseif event == 'CHAT_MSG_COMBAT_XP_GAIN' then
    local xp,name = parseKill(...)
    if xp then addKill(xp,name); refresh() end
  elseif event == 'PLAYER_LEVEL_UP' then
    priorLevel = UnitLevel('player')
    refresh()
  else refresh() end
end)
SLASH_KTD1='/ktd'
SLASH_KTD2='/ktl'
SLASH_KTD3='/killstoding'
SlashCmdList.KTD = function(input)
  if not db then return end
  local command,arg = (input or ''):lower():match('^(%S*)%s*(%S*)')
  if command == 'show' then db.visible=true;applyVisibility()
  elseif command == 'hide' then db.visible=false;applyVisibility()
  elseif command == 'minimize' or command == 'collapse' then db.visible=true;setCollapsed(true)
  elseif command == 'maximize' or command == 'expand' then db.visible=true;setCollapsed(false)
  elseif command == 'levels' then db.levelsVisible=not db.levelsVisible
  elseif command == 'reset' then db.samples={};db.byLevel={};notice('Samples cleared.')
  elseif command == 'samples' then
    local n=tonumber(arg)
    if not n or n < 1 or n > MAX_SAMPLES then notice('Usage: /ktd samples 1-50');return end
    db.sampleSize=math.floor(n)
    while #db.samples>db.sampleSize do table.remove(db.samples,1) end
    for _,values in pairs(db.byLevel) do while #values>db.sampleSize do table.remove(values,1) end end
  elseif command == 'range' then
    local n=tonumber(arg)
    if not n or n<0 or n>10 then notice('Usage: /ktd range 0-10');return end
    db.range=math.floor(n)
  elseif command == 'center' then
    panel:ClearAllPoints();panel:SetPoint('CENTER',UIParent,'CENTER',0,0)
    mini:ClearAllPoints();mini:SetPoint('CENTER',UIParent,'CENTER',0,0)
    db.point,db.relativePoint,db.x,db.y='CENTER','CENTER',0,0
  elseif command == 'size' then
    local n=tonumber(arg)
    if not n then notice('Usage: /ktd size 245-520'); return end
    db.windowWidth=clamp(math.floor(n),245,520)
  else notice('/ktd show | hide | minimize | maximize | size 245-520 | levels | range 0-10 | samples 1-50 | reset | center') end
  refresh()
end
