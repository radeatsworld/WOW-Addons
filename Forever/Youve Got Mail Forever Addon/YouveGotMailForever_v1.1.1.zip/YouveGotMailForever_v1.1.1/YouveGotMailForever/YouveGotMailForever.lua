local addonName = ...
local frame = CreateFrame("Frame")
local prefix = "|cff33ccffYou've Got Mail Forever:|r "
local soundPath = "Interface\\AddOns\\YouveGotMailForever\\Sounds\\youvegotmail.mp3"
local enabled, announced, initialized = true, false, false
local pendingCheck = false

local function Say(message)
    if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(prefix .. message) end
end

local function PlayNotification()
    if type(PlaySoundFile) ~= "function" then
        Say("Sound playback API unavailable.")
        return
    end
    local ok, result = pcall(PlaySoundFile, soundPath, "Master")
    if not ok or result == false then
        Say("Could not play audio. Add Sounds\\youvegotmail.mp3 and check its encoding.")
    end
end

local function HasPendingMail()
    -- HasNewMail is retained on some modern client builds; use it if present.
    if type(HasNewMail) == "function" then
        local ok, result = pcall(HasNewMail)
        if ok and type(result) == "boolean" then return result end
    end
    -- Blizzard's mailbox indicator is updated by the client when mail is pending.
    if MiniMapMailFrame and type(MiniMapMailFrame.IsShown) == "function" then
        local ok, shown = pcall(MiniMapMailFrame.IsShown, MiniMapMailFrame)
        if ok and type(shown) == "boolean" then return shown end
    end
    return nil
end

local function CheckMail()
    pendingCheck = false
    if not initialized or not enabled then return end
    local hasMail = HasPendingMail()
    if hasMail == true and not announced then
        announced = true
        PlayNotification()
    elseif hasMail == false then
        announced = false
    end
end

local function QueueCheck()
    if pendingCheck then return end
    pendingCheck = true
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(0.5, CheckMail)
    else
        CheckMail()
    end
end

frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("UPDATE_PENDING_MAIL")
frame:RegisterEvent("MAIL_INBOX_UPDATE")
frame:RegisterEvent("MAIL_SHOW")
frame:SetScript("OnEvent", function(self, event, name)
    if event == "ADDON_LOADED" then
        if name ~= addonName then return end
        if type(YGMForeverDB) ~= "table" then YGMForeverDB = {} end
        if YGMForeverDB.enabled == nil then YGMForeverDB.enabled = true end
        enabled = YGMForeverDB.enabled ~= false
        initialized = true
    elseif event == "PLAYER_ENTERING_WORLD" then
        -- Re-arm on each character login, including when mail was already waiting.
        announced = false
        QueueCheck()
        if C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(3, CheckMail)
        end
    else
        QueueCheck()
    end
end)

SLASH_YGMFOREVER1 = "/ygm"
SlashCmdList.YGMFOREVER = function(message)
    local command = (message or ""):match("^%s*(%S+)")
    command = command and command:lower() or ""
    if command == "test" then
        PlayNotification()
        Say("Test requested. If silent, confirm the MP3 is installed and sound is enabled.")
    elseif command == "on" then
        enabled = true
        YGMForeverDB = YGMForeverDB or {}
        YGMForeverDB.enabled = true
        announced = false
        Say("Enabled.")
        QueueCheck()
    elseif command == "off" then
        enabled = false
        YGMForeverDB = YGMForeverDB or {}
        YGMForeverDB.enabled = false
        Say("Disabled.")
    elseif command == "status" then
        Say("Version 1.1.0; notifications " .. (enabled and "enabled" or "disabled") .. ".")
    else
        Say("Commands: /ygm test, /ygm on, /ygm off, /ygm status")
    end
end
