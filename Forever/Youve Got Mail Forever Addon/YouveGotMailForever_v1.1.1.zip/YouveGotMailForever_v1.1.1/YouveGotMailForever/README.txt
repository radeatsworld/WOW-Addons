You've Got Mail Forever v1.1.0 - WoW Forever 1.60.1

Install folder: World of Warcraft/_forever_/Interface/AddOns/YouveGotMailForever/
(The exact game installation directory may differ.)

Add your own audio file to Sounds/youvegotmail.mp3

Commands:
/ygm test   Test the audio
/ygm on     Enable notifications
/ygm off    Disable notifications
/ygm status Show version and state

Detects pending mail on login and after mail events. It does not inspect
individual messages or announce each message separately. Detection relies
on the client mail indicator and available mail APIs. In-game verification
is required on your installed Forever build.
