Kills To Ding Forever v1.2.1
For WoW Forever (Interface 16001)

Install: Extract the KillsToDingForever folder into your Forever client's Interface/AddOns folder. Restart the game and enable the addon.

Commands:
/ktd - help
/ktd show - show tracker
/ktd hide - hide tracker
/ktd levels - toggle enemy-level table
/ktd range 5 - display 5 levels below and above (0-10 supported)
/ktd samples 50 - rolling kill sample size (1-50)
/ktd reset - clear kill XP history
/ktd center - center window
/ktl - legacy command alias

Enemy-level XP is measured when an English XP kill message matches a recently targeted enemy. Unmatched kills still contribute to the global average. A tilde (~) means a rough estimate extrapolated from global samples, NOT a server-verified XP formula. Before any kills, unavailable rows display --. Group kills and rapid target changes may prevent attribution. Quest XP is not counted. Rested XP is included in observed values.

This version has not been tested in the WoW Forever client. The XP chat message parser may need adjustment for the server's actual messages.

Version 1.2.1: aligned table columns; green/yellow/red enemy-level tiers.

Version 1.2.1 UI changes:
- Current Level label on first line.
- XP and Remaining XP share the second line, separated by 16 pixels.
- Kills to ding on third line; average kill and samples remain internal.
- Current-level table row uses larger bold-style font; no > marker.
- No ~ suffix in XP/kill values; footer reads "~ values".
- Existing green/yellow/red level coloring and fixed columns retained.
