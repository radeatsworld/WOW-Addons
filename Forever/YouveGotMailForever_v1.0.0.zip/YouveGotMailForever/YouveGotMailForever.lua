local addon = CreateFrame("Frame")
local prefix = "|cff33ccffYou've Got Mail Forever:|r "
local sound = "Interface\\AddOns\\YouveGotMailForever\\Sounds\\youvegotmail.mp3"
local enabled = true
local announced = false
local ready = false
local function say(msg) DEFAULT_CHAT_FRAME:AddMessage(prefix .. msg) end
local function play()
  if not enabled then return end
  PlaySoundFile(sound)
end
local function checkMail()
  if not ready or not enabled then return end
  local hasMail = HasNewMail()
  if hasMail and not announced then
    announced = true
    play()
  elseif not hasMail then
    announced = false
  end
end
addon:RegisterEvent("VARIABLES_LOADED")
addon:RegisterEvent("PLAYER_ENTERING_WORLD")
addon:RegisterEvent("UPDATE_PENDING_MAIL")
addon:RegisterEvent("MAIL_INBOX_UPDATE")
addon:SetScript("OnEvent", function()
  if event == "VARIABLES_LOADED" then
    if type(YGMForeverDB) ~= "table" then YGMForeverDB = {} end
    if YGMForeverDB.enabled == nil then YGMForeverDB.enabled = true end
    enabled = YGMForeverDB.enabled
  elseif event == "PLAYER_ENTERING_WORLD" then
    ready = true
    checkMail()
  elseif event == "UPDATE_PENDING_MAIL" or event == "MAIL_INBOX_UPDATE" then
    checkMail()
  end
end)
SLASH_YGMFOREVER1 = "/ygm"
SlashCmdList["YGMFOREVER"] = function(msg)
  msg = string.lower(msg or "")
  if msg == "test" then
    PlaySoundFile(sound)
    say("Playing notification. If silent, check the audio file path and sound settings.")
  elseif msg == "on" then
    enabled = true; YGMForeverDB.enabled = true
    say("Enabled.")
    checkMail()
  elseif msg == "off" then
    enabled = false; YGMForeverDB.enabled = false
    say("Disabled.")
  else
    say("Commands: /ygm test, /ygm on, /ygm off")
  end
end
