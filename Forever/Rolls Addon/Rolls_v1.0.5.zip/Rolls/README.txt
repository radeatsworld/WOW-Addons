Rolls 1.0.4: native C_LootHistory polling and events when available, chat fallback, separate manual /roll history including repeated rolls. /rolls debug and /rolls trace capture chat. Not tested in WoW Forever. Native API signatures may differ. Manual rolls do not imply an item winner.

1.0.5: Native-style loot history skin, item icons, selection icons and scrollbar. Tracking logic retained from 1.0.4; not tested in WoW Forever.
