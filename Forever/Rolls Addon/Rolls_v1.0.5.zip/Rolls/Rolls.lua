
SLASH_ROLLSBOOT1="/rollscheck"
SlashCmdList["ROLLSBOOT"]=function()
 if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("Rolls: Lua file started. If /rolls fails, a UI initialization error occurred.") end
end
local addon = CreateFrame("Frame", "RollsEventFrame")
local entries, order, rows = {}, {}, {}
local db = RollsDB or {announce=true}
local colors = {
 [0]="|cffffffff", [1]="|cffffffff", [2]="|cff1eff00",
 [3]="|cff0070dd", [4]="|cffa335ee", [5]="|cffff8000"
}
local function say(msg)
 if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffd8b45aRolls:|r "..msg) end
end
local function qualityColor(link)
 if link and GetItemInfo then
  local _,_,q=GetItemInfo(link)
  if q then return colors[q] or colors[1] end
 end
 local c=link and link:match("^(|c%x%x%x%x%x%x%x%x)")
 for i=2,5 do if c and c:lower()==colors[i] then return colors[i] end end
 return colors[1]
end
local function nameFromLink(link)
 if not link then return "Unknown item" end
 return string.match(link, "%[(.-)%]") or link
end
local function clean(s)
 if not s then return "" end
 return string.gsub(s, "|c%x%x%x%x%x%x%x%x", "")
end
local function short(s,n)
 if not s then return "" end
 if string.len(s)>n then return string.sub(s,1,n-3).."..." end
 return s
end
local function makeText(parent,size)
 local t=parent:CreateFontString(nil,"OVERLAY")
 t:SetFont("Fonts\\FRIZQT__.TTF",size or 12)
 t:SetJustifyH("LEFT")
 return t
end
local frame=CreateFrame("Frame","RollsWindow",UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
frame:SetFrameStrata("DIALOG")
frame:SetWidth(460); frame:SetHeight(400)
frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
frame:SetMovable(true); frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart",function(self) if not db or not db.locked then self:StartMoving() end end)
frame:SetScript("OnDragStop",function(self)
 self:StopMovingOrSizing()
 if db then local _,_,_,x,y=self:GetPoint(); db.x=x; db.y=y end
end)
if frame.SetBackdrop then frame:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
 edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
 insets={left=7,right=7,top=7,bottom=7}}) end
if frame.SetBackdropColor then frame:SetBackdropColor(0.05,0.04,0.025,0.98) end
frame:Hide()
local banner=frame:CreateTexture(nil,"ARTWORK")
banner:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Header");banner:SetWidth(260);banner:SetHeight(64);banner:SetPoint("TOP",frame,"TOP",0,12)
local title=makeText(frame,16); title:SetPoint("TOP",frame,"TOP",0,-8); title:SetText("Rolls - Loot History");title:SetTextColor(1,0.82,0)
local function button(parent,label,w,h)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetWidth(w);b:SetHeight(h);b:SetText(label)
 return b
end
local minimize=button(frame,"_",24,22);minimize:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-38,-10)
local close=CreateFrame("Button",nil,frame,"UIPanelCloseButton");close:SetWidth(28);close:SetHeight(28);close:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-12,-10)
close:SetScript("OnClick",function() frame:Hide() end)
local expand=button(frame,"Expand All",96,22);expand:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-40)
local collapse=button(frame,"Collapse All",104,22);collapse:SetPoint("LEFT",expand,"RIGHT",4,0)
local clear=button(frame,"Clear",55,22);clear:SetPoint("LEFT",collapse,"RIGHT",4,0)
local scroll=CreateFrame("ScrollFrame","RollsScroll",frame)
scroll:SetPoint("TOPLEFT",frame,"TOPLEFT",15,-70)
scroll:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-33,17)
local content=CreateFrame("Frame",nil,scroll);content:SetWidth(408);content:SetHeight(1)
scroll:SetScrollChild(content)
local mini=button(UIParent,"Rolls",65,25)
mini:SetPoint("CENTER",UIParent,"CENTER",0,0);mini:Hide()
mini:SetMovable(true);mini:EnableMouse(true);mini:RegisterForDrag("LeftButton")
mini:SetScript("OnDragStart",function(self) self:StartMoving() end)
mini:SetScript("OnDragStop",function(self) self:StopMovingOrSizing() end)
mini:SetScript("OnClick",function() mini:Hide();frame:Show() end)
minimize:SetScript("OnClick",function() frame:Hide();mini:ClearAllPoints();mini:SetPoint("CENTER",frame,"CENTER",0,0);mini:Show() end)
local function getRow(i)
 if rows[i] then return rows[i] end
 local r=CreateFrame("Button",nil,content)
 r:SetWidth(405);r:SetHeight(25)
 r.bg=r:CreateTexture(nil,"BACKGROUND");r.bg:SetAllPoints(r);r.bg:SetColorTexture(0.14,0.10,0.055,0.85)
 r.label=makeText(r,12);r.label:SetPoint("LEFT",r,"LEFT",60,0);r.label:SetWidth(335)
 r.item=r:CreateTexture(nil,"ARTWORK");r.item:SetWidth(24);r.item:SetHeight(24);r.item:SetPoint("LEFT",r,"LEFT",28,0)
 r.toggle=r:CreateTexture(nil,"ARTWORK");r.toggle:SetWidth(16);r.toggle:SetHeight(16);r.toggle:SetPoint("LEFT",r,"LEFT",7,0)
 r.choice=makeText(r,12);r.choice:SetPoint("LEFT",r,"LEFT",245,0);r.choice:SetWidth(95)
 r.number=makeText(r,12);r.number:SetPoint("RIGHT",r,"RIGHT",-12,0);r.number:SetJustifyH("RIGHT");r.number:SetWidth(65)
 r:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight","ADD")
 r:SetScript("OnClick",function(self)
  local e=entries[self.entryId]
  if e and self.header then e.open=not e.open; RollsRefresh() end
 end)
 r:SetScript("OnEnter",function(self)
  local e=entries[self.entryId]
  if e and self.header and e.link and GameTooltip then GameTooltip:SetOwner(self,"ANCHOR_RIGHT");GameTooltip:SetHyperlink(e.link);GameTooltip:Show() end
 end)
 r:SetScript("OnLeave",function() GameTooltip:Hide() end)
 rows[i]=r;return r
end
local function layoutRow(i,e,y,header)
 local r=getRow(i);r.entryId=e.id;r.header=header
 r:ClearAllPoints();r:SetPoint("TOPLEFT",content,"TOPLEFT",0,-y)
 r.choice:SetText("");r.number:SetText("");r.item:Hide();r.toggle:Hide()
 r.label:ClearAllPoints();r.label:SetPoint("LEFT",r,"LEFT",header and 60 or 34,0);r.label:SetWidth(header and 335 or 190)
 r.label:SetTextColor(1,1,1);r.choice:SetTextColor(1,0.82,0);r.number:SetTextColor(1,1,1)
 r.bg:SetColorTexture(header and 0.24 or 0.075,header and 0.17 or 0.065,header and 0.08 or 0.045,0.9)
 r:SetHeight(header and 32 or 25);r:Show();return r
end
function RollsRefresh()
 local index,y=0,0
 for k=1,#order do
  local e=entries[order[k]]
  if e then
   index=index+1;local r=layoutRow(index,e,y,true)
   r.toggle:SetTexture(e.open and "Interface\\Buttons\\UI-MinusButton-Up" or "Interface\\Buttons\\UI-PlusButton-Up");r.toggle:Show()
   local tex=e.texture or (e.link and GetItemIcon and GetItemIcon(e.link)) or (e.id=="manual" and "Interface\\Buttons\\UI-GroupLoot-Dice-Up") or "Interface\\Icons\\INV_Misc_QuestionMark"
   r.item:SetTexture(tex);r.item:Show()
   r.label:SetText(qualityColor(e.link)..e.name.."|r"..(e.winner and " |cffedd077*|r" or ""));y=y+34
   if e.open then
    index=index+1;local h=layoutRow(index,e,y,false);h.label:SetText("Player");h.label:SetTextColor(1,0.82,0);h.choice:SetText(e.id=="manual" and "Range" or "Selection");h.number:SetText("Roll");h.number:SetTextColor(1,0.82,0);y=y+25
    for j=1,#e.rolls do
     local v=e.rolls[j];index=index+1;local sub=layoutRow(index,e,y,false)
     sub.label:SetText(v.player);sub.choice:SetText(v.choice);sub.number:SetText(tostring(v.number or "-"))
     local icons={Need="Interface\\Buttons\\UI-GroupLoot-Dice-Up",Greed="Interface\\Buttons\\UI-GroupLoot-Coin-Up",Pass="Interface\\Buttons\\UI-GroupLoot-Pass-Up",Disenchant="Interface\\Buttons\\UI-GroupLoot-DE-Up"}
     if icons[v.choice] then sub.toggle:SetTexture(icons[v.choice]);sub.toggle:Show() end
     if e.winner==v.player then sub.label:SetTextColor(0.25,1,0.25);sub.number:SetTextColor(0.25,1,0.25) end
     y=y+25
    end
    if e.winner then index=index+1;local sub=layoutRow(index,e,y,false);sub.label:SetWidth(365);sub.label:SetText("|cff40ff40Winner: "..e.winner.."|r");y=y+25 end
   end
   y=y+4
  end
 end
 for i=index+1,#rows do rows[i]:Hide() end
 content:SetHeight(math.max(y,1))
 local limit=math.max(0,y-scroll:GetHeight());scroll:SetVerticalScroll(math.min(scroll:GetVerticalScroll(),limit))
end
local function newEntry(id,link)
 if entries[id] then return entries[id] end
 local e={id=id,link=link,name=nameFromLink(link),rolls={},open=true,created=GetTime(),winner=nil}
 entries[id]=e;table.insert(order,1,id)
 RollsRefresh();return e
end
local function updateChoice(e,player,choice,number)
 if not e or not player then return end
 for i=1,#e.rolls do
  local r=e.rolls[i]
  if r.player==player then
   if (choice and choice~=r.choice) or (number and number~=r.number) then r.choice=choice or r.choice;r.number=number or r.number;e.open=true;RollsRefresh() end;return
  end
 end
 table.insert(e.rolls,{player=player,choice=choice or "Rolling",number=number})
 e.open=true;RollsRefresh()
end
local function announce(e)
 if not e or not e.winner or e.announced then return end
 e.announced=true
 local msg=e.winner.." won "..e.name
 if db and db.announce then
  local channel
  if (IsInRaid and IsInRaid()) or (GetNumRaidMembers and GetNumRaidMembers()>0) then channel="RAID"
  elseif (IsInGroup and IsInGroup()) or (GetNumPartyMembers and GetNumPartyMembers()>0) then channel="PARTY" end
  if channel then SendChatMessage(msg,channel) end
 end
 say(msg)
end
local serial=0
local native = {}
local function history()
 local h=C_LootHistory
 if not h or not h.GetNumItems or not h.GetItem or not h.GetPlayerInfo then return end
 local ok,n=pcall(h.GetNumItems); if not ok or type(n)~="number" then return end
 for i=1,n do
  local good,id,link,np,done,winner=pcall(h.GetItem,i)
  if good and type(link)=="string" and type(np)=="number" then
   local e=native[id or i]
   if not e or entries[e.id]~=e or e.link~=link then
    for _,eid in ipairs(order) do local candidate=entries[eid]; if candidate and candidate.rollID==id then e=candidate;break end end
    if not e or entries[e.id]~=e or e.link~=link then serial=serial+1;e=newEntry("native:"..serial,link) end
    native[id or i]=e
   end
   e.native=true
   for j=1,np do
    local success,name,class,kind,roll,isWinner=pcall(h.GetPlayerInfo,i,j)
    if success and name then
     local choice=({[0]="Pass",[1]="Need",[2]="Greed",[3]="Disenchant"})[kind] or "Pending"
     updateChoice(e,name,choice,roll)
     if done and (isWinner==true or winner==j) then e.winner=name end
    end
   end
   if done then e.finished=true; if e.winner then announce(e) end end
  end
 end
 RollsRefresh()
end
local function manual(msg)
 local name,value,low,high=msg:match("^(.+) rolls (%d+) %((%d+)%s*%-%s*(%d+)%)%.?$")
 if not name then return end
 local e=entries.manual or newEntry("manual",nil); e.name="Manual /roll results"
 table.insert(e.rolls,{player=name,choice="("..low.."-"..high..")",number=value});e.open=true;RollsRefresh()
end
local function key(link) return link and link:match('|H(item:[^|]+)|h') end
local function entryForLink(link)
 local found
 for i=1,#order do
  local e=entries[order[i]]
  if e and key(e.link)==key(link) and not e.winner and not e.finished then
   if found then return nil,true end
   found=e
  end
 end
 return found,false
end
local function lootLink(msg)
 return msg and (msg:match('(|c%x%x%x%x%x%x%x%x|Hitem:.-|h%[.-%]|h|r)') or msg:match('(|Hitem:.-|h%[.-%]|h)'))
end
local function parseMessage(msg)
 local link=lootLink(msg)
 if not link then return end
 local plain=msg:gsub('|c%x%x%x%x%x%x%x%x',''):gsub('|r',''):gsub('|Hitem:.-|h.-|h','ITEM')
 local player,choice,number
 choice,number,player=plain:match('^([%a]+) Roll%s*%-%s*(%d+)%s+for%s+ITEM%s+by%s+(.+)$')
 if not player then choice,number,player=plain:match('^([%a]+) Roll%s*%-%s*(%d+)%s+for%s+ITEM%s+by%s+(.+)%s*$') end
 if not player then player,choice=plain:match('^(.-) has selected ([%a]+) for: ?ITEM') end
 if not player then player,choice=plain:match('^(.-) have selected ([%a]+) for: ?ITEM') end
 if not player then player=plain:match('^(.-) passed on: ?ITEM') or plain:match('^(.-) passes on: ?ITEM'); if player then choice='Pass' end end
 if not player then player=plain:match('^(.-) has passed on: ?ITEM'); if player then choice='Pass' end end
 local winner=plain:match('^(.-) won: ?ITEM') or plain:match('^(.-) wins: ?ITEM') or plain:match('^(.-) won ITEM') or plain:match('^(.-) wins ITEM')
 local allpass=plain:match('Everyone passed on: ?ITEM')
 if not player and not winner and not allpass then return end
 local e,ambiguous=entryForLink(link)
 if ambiguous then if db.debug then say('Ambiguous identical active items; chat result not assigned.') end; return end
 if not e then serial=serial+1;e=newEntry('chat:'..serial,link) end
 if e.native then return end
 if player then
  player=player:gsub('[%.%s]+$',''); if player=='You' then player=UnitName('player') end
  if choice then choice=choice:sub(1,1):upper()..choice:sub(2):lower() end
  updateChoice(e,player,choice,number)
 elseif winner then
  if winner=='You' then winner=UnitName('player') end
  e.winner=winner;e.open=true;announce(e);RollsRefresh()
 elseif allpass then e.finished=true; RollsRefresh() end
end
local function debugEvent(ev,msg)
 if not db.debug then return end
 db.trace=db.trace or {}; table.insert(db.trace,ev..': '..tostring(msg or ''))
 if #db.trace>100 then table.remove(db.trace,1) end
end
expand:SetScript("OnClick",function() for _,e in pairs(entries) do e.open=true end RollsRefresh() end)
collapse:SetScript("OnClick",function() for _,e in pairs(entries) do e.open=false end RollsRefresh() end)
clear:SetScript("OnClick",function() entries={};order={};RollsRefresh() end)
SLASH_ROLLS1="/rolls"
SlashCmdList["ROLLS"]=function(msg)
 msg=string.lower(msg or "")
 if msg=="clear" then entries={};order={};RollsRefresh();say("History cleared.")
 elseif msg=="announce" then db.announce=not db.announce;say("Chat announcements "..(db.announce and "on" or "off"))
 elseif msg=="lock" then db.locked=not db.locked;say("Window "..(db.locked and "locked" or "unlocked"))
 elseif msg=="test" then
  local e=newEntry("test:"..GetTime(),"|cff0070dd|Hitem:0:0:0:0|h[Sample Rare Sword]|h|r")
  updateChoice(e,"Slan","Need","94");updateChoice(e,"Thorin","Need","72")
  e.winner="Slan";e.announced=true;RollsRefresh();frame:Show()
 elseif msg=="debug" then db.debug=not db.debug; say("Debug capture "..(db.debug and "ON" or "OFF"))
 elseif msg=="trace" then for _,line in ipairs(db.trace or {}) do say(line) end
 elseif msg=="status" then say("Commands registered. UI="..(frame:IsShown() and "open" or "closed").."; entries="..#order)
 elseif msg=="help" then say("/rolls, /rolls test, /rolls clear, /rolls announce, /rolls lock, /rolls status")
 else if mini:IsShown() then mini:Hide();frame:Show() elseif frame:IsShown() then frame:Hide() else frame:Show() end end
end
addon:RegisterEvent("ADDON_LOADED")
addon:RegisterEvent("VARIABLES_LOADED")
addon:RegisterEvent("START_LOOT_ROLL")
addon:RegisterEvent("CANCEL_LOOT_ROLL")
addon:RegisterEvent("CHAT_MSG_LOOT")
addon:RegisterEvent("CHAT_MSG_SYSTEM")
addon:RegisterEvent("CHAT_MSG_RAID")
addon:RegisterEvent("CHAT_MSG_PARTY")
addon:SetScript("OnEvent",function(self, event, ...)
 local arg1 = ...
 if event=="START_LOOT_ROLL" or event=="CANCEL_LOOT_ROLL" or event=="CHAT_MSG_LOOT" or event=="CHAT_MSG_SYSTEM" then debugEvent(event,arg1) end
 if (event=="ADDON_LOADED" and arg1=="Rolls") or event=="VARIABLES_LOADED" then
  RollsDB=RollsDB or {};db=RollsDB
  if db.announce==nil then db.announce=true end
  if db.x and db.y then frame:ClearAllPoints();frame:SetPoint("CENTER",UIParent,"CENTER",db.x,db.y) end
  say("Loaded. Type /rolls to open, /rolls help for commands.")
 elseif event=="START_LOOT_ROLL" then
  local rollID=arg1
  if GetLootRollItemInfo then
   local texture,name,count,quality,bop,canNeed,canGreed=GetLootRollItemInfo(rollID)
   local link=GetLootRollItemLink and GetLootRollItemLink(rollID)
   if link then
    serial=serial+1
    local e=newEntry("roll:"..rollID..":"..serial,link)
    e.rollID=rollID; e.texture=texture; e.name=name or nameFromLink(link)
    e.open=true;RollsRefresh()
   end
  end
 elseif event:find("LOOT_HISTORY",1,true) then history()
 elseif event=="CANCEL_LOOT_ROLL" then
  -- Do not invent a winner when the server cancels a roll.
 elseif event=="CHAT_MSG_LOOT" or event=="CHAT_MSG_SYSTEM" then
  if event=="CHAT_MSG_SYSTEM" then manual(arg1 or "") end
  history(); parseMessage(arg1)
 end
end)

for _,ev in ipairs({"LOOT_HISTORY_FULL_UPDATE","LOOT_HISTORY_ROLL_CHANGED","LOOT_HISTORY_ROLL_COMPLETE","LOOT_HISTORY_AUTO_SHOW","LOOT_HISTORY_CLEAR_HISTORY"}) do pcall(addon.RegisterEvent,addon,ev) end
local elapsed=0
addon:SetScript("OnUpdate",function(self,dt) elapsed=elapsed+dt; if elapsed>=0.5 then elapsed=0; history() end end)
scroll:EnableMouseWheel(true)
scroll:SetScript("OnMouseWheel",function(self,delta) self:SetVerticalScroll(math.max(0,math.min(math.max(0,content:GetHeight()-self:GetHeight()),self:GetVerticalScroll()-delta*45))) end)

local bar=CreateFrame("Slider","RollsNativeScrollBar",frame,"UIPanelScrollBarTemplate")
bar:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-12,-87);bar:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-12,33)
bar:SetWidth(16);bar:SetMinMaxValues(0,0);bar:SetValueStep(1);bar:SetValue(0)
bar:SetScript("OnValueChanged",function(self,value) scroll:SetVerticalScroll(value) end)
scroll:SetScript("OnVerticalScroll",function(self,value) if math.abs(bar:GetValue()-value)>1 then bar:SetValue(value) end end)
scroll:SetScript("OnScrollRangeChanged",function(self,x,y) bar:SetMinMaxValues(0,math.max(0,y or 0));bar:SetValue(self:GetVerticalScroll()) end)
