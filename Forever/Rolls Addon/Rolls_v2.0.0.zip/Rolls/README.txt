Rolls 2.0.0 for Forever 1.60.1 (16001).
Delete old Rolls folder, extract this archive into _forever_/Interface/AddOns, restart.
/rolls opens actual Blizzard Loot Rolls window; hover items for native player results.
/rolls details opens separate expandable player list with manual rolls.
/rolls status reports API and item counts; /rolls trace reports history events.
/rolls auto and /rolls announce toggle automatic native opening and winner announcements.
Source reference: https://github.com/Gethe/wow-ui-source/blob/forever/Interface/AddOns/Blizzard_FrameXML/Mainline/LootHistory.lua
Native data coverage for ordinary trash drops is unverified. Manual parser targets English client. No in-game testing performed. No old chat-only item parser included. History is session/native history only. Native window appearance is unchanged; details window uses standard frame template. Prior minimize and expand-all controls not included.
