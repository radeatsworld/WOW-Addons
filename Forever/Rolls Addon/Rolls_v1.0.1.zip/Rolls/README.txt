Rolls 1.0.0 — experimental WoW Forever / classic-era loot tracker

INSTALL
Copy the Rolls folder into World of Warcraft/Interface/AddOns/.
Restart the client and enable Rolls in AddOns.
If marked out-of-date, check Load out of date AddOns.

COMMANDS
/rolls — toggle window
/rolls test — show sample roll (no chat announcement)
/rolls clear — clear current session
/rolls announce — toggle automatic party/raid winner announcement
/rolls lock — toggle movement lock
/rolls help — show commands

IMPORTANT
This is an initial client-compatibility build, not verified in WoW Forever.
The interface number 11200 targets a 1.12-style client. Change it if
your client uses another interface version.
WoW 1.12 does not expose a reliable per-player roll event for every
group-loot choice. This build captures START_LOOT_ROLL and attempts to
parse English loot/system chat messages. Exact Need/Greed/Pass values and
winner attribution may be incomplete or absent depending on server messages.
The addon will not fabricate missing roll results. For accurate results,
provide example chat logs and client interface version for adaptation.
No addon can read other players' private roll selections unless the client
or server exposes them through events or messages.
