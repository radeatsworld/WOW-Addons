
local addon = CreateFrame("Frame", "RollsEventFrame")
local entries, order, rows = {}, {}, {}
local db
local colors = {
 [0]="|cffffffff", [1]="|cffffffff", [2]="|cff1eff00",
 [3]="|cff0070dd", [4]="|cffa335ee", [5]="|cffff8000"
}
local function say(msg)
 if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage("|cffd8b45aRolls:|r "..msg) end
end
local function qualityColor(link)
 if link and GetItemInfo then
  local _,_,q=GetItemInfo(link)
  if q then return colors[q] or colors[1] end
 end
 return colors[1]
end
local function nameFromLink(link)
 if not link then return "Unknown item" end
 return string.match(link, "%[(.-)%]") or link
end
local function clean(s)
 if not s then return "" end
 return string.gsub(s, "|c%x%x%x%x%x%x%x%x", "")
end
local function short(s,n)
 if not s then return "" end
 if string.len(s)>n then return string.sub(s,1,n-3).."..." end
 return s
end
local function makeText(parent,size)
 local t=parent:CreateFontString(nil,"OVERLAY","GameFontNormal")
 t:SetFont("Fonts\\FRIZQT__.TTF",size or 12)
 t:SetJustifyH("LEFT")
 return t
end
local frame=CreateFrame("Frame","RollsWindow",UIParent)
frame:SetWidth(410); frame:SetHeight(320)
frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
frame:SetMovable(true); frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart",function() if not db or not db.locked then this:StartMoving() end end)
frame:SetScript("OnDragStop",function()
 this:StopMovingOrSizing()
 if db then local _,_,_,x,y=this:GetPoint(); db.x=x; db.y=y end
end)
frame:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
 edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
 insets={left=7,right=7,top=7,bottom=7}})
frame:SetBackdropColor(0.04,0.04,0.07,0.95)
frame:Hide()
local title=makeText(frame,16); title:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-14); title:SetText("Rolls")
local function button(parent,label,w,h)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
 b:SetWidth(w);b:SetHeight(h);b:SetText(label)
 return b
end
local minimize=button(frame,"_",24,22);minimize:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-38,-10)
local close=button(frame,"X",24,22);close:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-12,-10)
close:SetScript("OnClick",function() frame:Hide() end)
local expand=button(frame,"Expand All",96,22);expand:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-40)
local collapse=button(frame,"Collapse All",104,22);collapse:SetPoint("LEFT",expand,"RIGHT",4,0)
local clear=button(frame,"Clear",55,22);clear:SetPoint("LEFT",collapse,"RIGHT",4,0)
local scroll=CreateFrame("ScrollFrame","RollsScroll",frame,"UIPanelScrollFrameTemplate")
scroll:SetPoint("TOPLEFT",frame,"TOPLEFT",15,-70)
scroll:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-33,17)
local content=CreateFrame("Frame",nil,scroll);content:SetWidth(345);content:SetHeight(1)
scroll:SetScrollChild(content)
local mini=button(UIParent,"Rolls",65,25)
mini:SetPoint("CENTER",UIParent,"CENTER",0,0);mini:Hide()
mini:SetMovable(true);mini:EnableMouse(true);mini:RegisterForDrag("LeftButton")
mini:SetScript("OnDragStart",function() this:StartMoving() end)
mini:SetScript("OnDragStop",function() this:StopMovingOrSizing() end)
mini:SetScript("OnClick",function() mini:Hide();frame:Show() end)
minimize:SetScript("OnClick",function() frame:Hide();mini:ClearAllPoints();mini:SetPoint("CENTER",frame,"CENTER",0,0);mini:Show() end)
local function getRow(i)
 if rows[i] then return rows[i] end
 local r=CreateFrame("Button",nil,content)
 r:SetWidth(340);r:SetHeight(25)
 r.bg=r:CreateTexture(nil,"BACKGROUND");r.bg:SetAllPoints(r);r.bg:SetTexture(0.14,0.14,0.18,0.75)
 r.label=makeText(r,12);r.label:SetPoint("LEFT",r,"LEFT",7,0);r.label:SetWidth(315)
 r:SetScript("OnClick",function()
  local e=entries[this.entryId]
  if e then e.open=not e.open; RollsRefresh() end
 end)
 r:SetScript("OnEnter",function()
  local e=entries[this.entryId]
  if e and e.link then GameTooltip:SetOwner(this,"ANCHOR_RIGHT");GameTooltip:SetHyperlink(e.link);GameTooltip:Show() end
 end)
 r:SetScript("OnLeave",function() GameTooltip:Hide() end)
 rows[i]=r;return r
end
function RollsRefresh()
 local index,y=0,0
 for k=1,table.getn(order) do
  local e=entries[order[k]]
  if e then
   index=index+1
   local r=getRow(index);r.entryId=e.id
   r:ClearAllPoints();r:SetPoint("TOPLEFT",content,"TOPLEFT",0,-y)
   r.label:SetText((e.open and "v " or "> ")..qualityColor(e.link)..short(e.name,31).."|r"..(e.winner and " |cffedd077*|r" or ""))
   r:Show();y=y+27
   if e.open then
    for j=1,table.getn(e.rolls) do
     local v=e.rolls[j];index=index+1
     local sub=getRow(index);sub.entryId=e.id
     sub:ClearAllPoints();sub:SetPoint("TOPLEFT",content,"TOPLEFT",0,-y)
     sub.label:SetText("    "..short(v.player,17).."  "..v.choice.."  "..(v.number or "-")..(e.winner==v.player and " |cff00ff00WIN|r" or ""))
     sub:Show();y=y+25
    end
    if e.winner then
     index=index+1;local sub=getRow(index);sub.entryId=e.id
     sub:ClearAllPoints();sub:SetPoint("TOPLEFT",content,"TOPLEFT",0,-y)
     sub.label:SetText("    |cff00ff00Winner: "..short(e.winner,24).."|r")
     sub:Show();y=y+25
    end
   end
  end
 end
 for i=index+1,table.getn(rows) do rows[i]:Hide() end
 content:SetHeight(math.max(y,1))
end
local function newEntry(id,link)
 if entries[id] then return entries[id] end
 local e={id=id,link=link,name=nameFromLink(link),rolls={},open=true,created=GetTime(),winner=nil}
 entries[id]=e;table.insert(order,1,id)
 RollsRefresh();return e
end
local function updateChoice(e,player,choice,number)
 if not e or not player then return end
 for i=1,table.getn(e.rolls) do
  local r=e.rolls[i]
  if r.player==player then
   r.choice=choice or r.choice;r.number=number or r.number;e.open=true;RollsRefresh();return
  end
 end
 table.insert(e.rolls,{player=player,choice=choice or "Rolling",number=number})
 e.open=true;RollsRefresh()
end
local function announce(e)
 if not e or not e.winner or e.announced then return end
 e.announced=true
 local msg=e.winner.." won "..e.name
 if db and db.announce then
  local channel
  if GetNumRaidMembers and GetNumRaidMembers()>0 then channel="RAID"
  elseif GetNumPartyMembers and GetNumPartyMembers()>0 then channel="PARTY" end
  if channel then SendChatMessage(msg,channel) end
 end
 say(msg)
end
local function entryForLink(link)
 for i=1,table.getn(order) do
  local e=entries[order[i]]
  if e and e.link==link and not e.winner then return e end
 end
 return nil
end
local function lootLink(msg)
 if not msg then return nil end
 return string.match(msg,"(|c%x%x%x%x%x%x%x%x|Hitem:.-|h%[.-%]|h|r)") or
        string.match(msg,"(|Hitem:.-|h%[.-%]|h)")
end
local function parseMessage(msg)
 local link=lootLink(msg)
 if not link then return end
 local e=entryForLink(link)
 -- English client messages are a fallback when the client does not expose full roll events.
 local player,number
 player,number=string.match(msg,"^(.-) rolls (%d+) .*")
 if player then
  e=e or newEntry("chat:"..link..":"..math.floor(GetTime()/120),link)
  updateChoice(e,player,"Roll",number)
  return
 end
 if string.find(string.lower(msg),"won") or string.find(string.lower(msg),"wins") then
  player=string.match(msg,"^(.-) wins ") or string.match(msg,"^(.-) won ")
  if player then
   e=e or newEntry("chat:"..link..":"..math.floor(GetTime()/120),link)
   e.winner=player;e.open=true;announce(e);RollsRefresh()
  end
 end
end
expand:SetScript("OnClick",function() for _,e in pairs(entries) do e.open=true end RollsRefresh() end)
collapse:SetScript("OnClick",function() for _,e in pairs(entries) do e.open=false end RollsRefresh() end)
clear:SetScript("OnClick",function() entries={};order={};RollsRefresh() end)
SLASH_ROLLS1="/rolls"
SlashCmdList["ROLLS"]=function(msg)
 msg=string.lower(msg or "")
 if msg=="clear" then entries={};order={};RollsRefresh();say("History cleared.")
 elseif msg=="announce" then db.announce=not db.announce;say("Chat announcements "..(db.announce and "on" or "off"))
 elseif msg=="lock" then db.locked=not db.locked;say("Window "..(db.locked and "locked" or "unlocked"))
 elseif msg=="test" then
  local e=newEntry("test:"..GetTime(),"|cff0070dd|Hitem:0:0:0:0|h[Sample Rare Sword]|h|r")
  updateChoice(e,"Slan","Need","94");updateChoice(e,"Thorin","Need","72")
  e.winner="Slan";e.announced=true;RollsRefresh();frame:Show()
 elseif msg=="help" then say("/rolls, /rolls test, /rolls clear, /rolls announce, /rolls lock")
 else if mini:IsShown() then mini:Hide();frame:Show() elseif frame:IsShown() then frame:Hide() else frame:Show() end end
end
addon:RegisterEvent("VARIABLES_LOADED")
addon:RegisterEvent("START_LOOT_ROLL")
addon:RegisterEvent("CANCEL_LOOT_ROLL")
addon:RegisterEvent("CHAT_MSG_LOOT")
addon:RegisterEvent("CHAT_MSG_SYSTEM")
addon:RegisterEvent("CHAT_MSG_RAID")
addon:RegisterEvent("CHAT_MSG_PARTY")
addon:SetScript("OnEvent",function()
 if event=="VARIABLES_LOADED" then
  RollsDB=RollsDB or {};db=RollsDB
  if db.announce==nil then db.announce=true end
  if db.x and db.y then frame:ClearAllPoints();frame:SetPoint("CENTER",UIParent,"CENTER",db.x,db.y) end
  say("Loaded. Type /rolls to open, /rolls help for commands.")
 elseif event=="START_LOOT_ROLL" then
  local rollID=arg1
  if GetLootRollItemInfo then
   local texture,name,count,quality,bop,canNeed,canGreed=GetLootRollItemInfo(rollID)
   local link=GetLootRollItemLink and GetLootRollItemLink(rollID)
   if link then
    local e=newEntry("roll:"..rollID,link)
    e.name=name or nameFromLink(link)
    e.open=true;RollsRefresh()
   end
  end
 elseif event=="CANCEL_LOOT_ROLL" then
  -- Do not invent a winner when the server cancels a roll.
 elseif event=="CHAT_MSG_LOOT" or event=="CHAT_MSG_SYSTEM" then
  parseMessage(arg1)
 end
end)
