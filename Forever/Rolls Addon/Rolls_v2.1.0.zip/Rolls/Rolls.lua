local f=CreateFrame('Frame')
local db, panel, text, scroll
local records, order, manual, seen, trace = {}, {}, {}, {}, {}
local initialized=false
local live, liveOrder, liveSeq = {}, {}, 0
local function itemLink(msg)
 return msg and (msg:match('(|c%x%x%x%x%x%x%x%x|Hitem:.-|h%[.-%]|h|r)') or msg:match('(|Hitem:.-|h%[.-%]|h)'))
end
local function ensureLive(link,id)
 local key=id or ('chat:'..tostring(link))
 local r=live[key]
 if not r then
  r={link=link or 'Unknown item',open=true,players={},winner=nil,key=key}
  live[key]=r; table.insert(liveOrder,1,key)
 end
 if link then r.link=link end
 return r
end
local function addLiveRoll(r,player,choice,number)
 if not r or not player or player=='' then return end
 local old=r.players[player] or {}
 if choice then old.choice=choice end
 if number then old.number=tonumber(number) or number end
 r.players[player]=old;r.open=true
end
local function liveForLink(link)
 for _,key in ipairs(liveOrder) do
  local r=live[key]
  if r and r.link==link and not r.winner then return r end
 end
 return ensureLive(link)
end
local render
local function parseLoot(msg,ev)
 if not msg then return end
 local link=itemLink(msg)
 if not link then return end
 local plain=msg:gsub('|c%x%x%x%x%x%x%x%x',''):gsub('|r','')
 local who,number,choice
 -- Known English client formats. Unknown formats are recorded in /rolls trace.
 who,number=plain:match('^(.+) rolls (%d+) %(')
 if not who then who,number=plain:match('^(.+) rolls (%d+) for ') end
 if who and number then
  local r=liveForLink(link); addLiveRoll(r,who,'Roll',number);render();return
 end
 who,choice=plain:match('^(.+) has selected (Need) for')
 if not who then who,choice=plain:match('^(.+) has selected (Greed) for') end
 if not who then who,choice=plain:match('^(.+) has selected (Pass) for') end
 if not who then who,choice=plain:match('^(.+) chooses (Need) for') end
 if not who then who,choice=plain:match('^(.+) chooses (Greed) for') end
 if not who then who,choice=plain:match('^(.+) passes on') end
 if who then
  local r=liveForLink(link);addLiveRoll(r,who,choice or 'Pass');render();return
 end
 who=plain:match('^(.+) won:') or plain:match('^(.+) wins ') or plain:match('^(.+) won ')
 if who then
  local r=liveForLink(link);r.winner=who;r.open=true;render();return
 end
 log('UNPARSED '..ev..' '..msg)
end

local function say(s) print('|cffffd100Rolls:|r '..s) end
local function log(s) trace[#trace+1]=s; if #trace>60 then table.remove(trace,1) end end
local function call(fn, ...) if type(fn)~='function' then return end; local ok,v=pcall(fn,...); if ok then return v end; log(tostring(v)) end
local function native() return _G.GroupLootHistoryFrame end
local function openNative(id)
 local n=native(); if not n then say('Native loot window unavailable.'); return end
 n:Show(); if id and n.OpenToEncounter then call(n.OpenToEncounter,n,id) end
end
local function state(v)
 local e=Enum and Enum.EncounterLootDropRollState or {}
 for _,k in ipairs({'NeedMainSpec','NeedOffSpec','Greed','Pass','Transmog','Disenchant','NoRoll'}) do
 if e[k]~=nil and v==e[k] then return ({NeedMainSpec='Need',NeedOffSpec='Need (off spec)',NoRoll='Pending'})[k] or k end end
 return 'Unknown'
end
render=function()
 if not panel or not panel:IsShown() then return end
 local y=0
 for _,b in ipairs(panel.rows) do b:Hide() end
 local i=0
 local function row(label,click,link)
  i=i+1; local b=panel.rows[i]
  if not b then b=CreateFrame('Button',nil,scroll.child); b:SetSize(420,22); b:SetHighlightTexture('Interface\\QuestFrame\\UI-QuestTitleHighlight'); b.t=b:CreateFontString(nil,'OVERLAY','GameFontHighlight'); b.t:SetPoint('LEFT',4,0); b.t:SetWidth(410); b.t:SetJustifyH('LEFT'); panel.rows[i]=b end
  b:ClearAllPoints(); b:SetPoint('TOPLEFT',0,-y); y=y+22; b.t:SetText(label); b:SetScript('OnClick',click); b:SetScript('OnEnter',link and function(self) GameTooltip:SetOwner(self,'ANCHOR_RIGHT'); GameTooltip:SetHyperlink(link); GameTooltip:Show() end or nil); b:SetScript('OnLeave',function() GameTooltip:Hide() end); b:Show()
 end
 for _,key in ipairs(liveOrder) do
  local r=live[key]
  if r then
   local link=r.link or 'Unknown item'
   local name=link:match('%[(.-)%]') or link
   local color=link:match('|c(%x%x%x%x%x%x%x%x)') or 'ffffffff'
   if color~='ff1eff00' and color~='ff0070dd' and color~='ffa335ee' and color~='ffff8000' then color='ffffffff' end
   row((r.open and '- ' or '+ ')..'|c'..color..name..'|r'..(r.winner and ' |cff00ff00Winner: '..r.winner..'|r' or ''),function() r.open=not r.open;render() end,link)
   if r.open then
    local names={};for n in pairs(r.players) do table.insert(names,n) end;table.sort(names)
    for _,n in ipairs(names) do local v=r.players[n];row('    '..n..'  '..(v.choice or 'Pending')..'  '..tostring(v.number or '-')) end
   end
  end
 end
 for j=#order,1,-1 do local r=records[order[j]]; if r then
  local link=r.data.itemHyperlink or 'Unknown item'; local name=link:match('%[(.-)%]') or link; local color=link:match('|c(%x%x%x%x%x%x%x%x)'); if color~='ff1eff00' and color~='ff0070dd' and color~='ffa335ee' and color~='ffff8000' then color='ffffffff' end
  row((r.open and '- ' or '+ ')..'|c'..color..name..'|r'..(r.data.winner and '  |cff00ff00'..(r.data.winner.playerName or '?')..'|r' or ''),function() r.open=not r.open; render() end,r.data.itemHyperlink)
  if r.open then for _,p in ipairs(r.data.rollInfos or {}) do row('    '..(p.isWinner and '|cff00ff00' or '|cffffffff')..(p.playerName or '?')..'   '..state(p.state)..'   '..tostring(p.roll or '-')..'|r') end; if r.data.allPassed then row('    Everyone passed') end end
 end end
 row((panel.manualOpen and '- ' or '+ ')..'Manual /roll results ('..#manual..')',function() panel.manualOpen=not panel.manualOpen; render() end)
 if panel.manualOpen then for j=#manual,1,-1 do row('    '..manual[j]) end end
 scroll.child:SetHeight(math.max(y,1))
end
local function details()
 if not panel then
  panel=CreateFrame('Frame','RollsDetails',UIParent,'BasicFrameTemplateWithInset'); panel:SetSize(465,420); panel:SetPoint('CENTER'); panel:SetMovable(true); panel:EnableMouse(true); panel:RegisterForDrag('LeftButton'); panel:SetScript('OnDragStart',panel.StartMoving); panel:SetScript('OnDragStop',panel.StopMovingOrSizing); panel.TitleText:SetText('Rolls - Details'); panel.rows={}; panel.manualOpen=true
  scroll=CreateFrame('ScrollFrame',nil,panel,'UIPanelScrollFrameTemplate'); scroll:SetPoint('TOPLEFT',12,-35); scroll:SetPoint('BOTTOMRIGHT',-32,12); scroll.child=CreateFrame('Frame',nil,scroll); scroll.child:SetSize(420,1); scroll:SetScrollChild(scroll.child)
 end
 panel:Show(); render()
end
local function update()
 local h=C_LootHistory; if not h then return end
 local enc=call(h.GetAllEncounterInfos); if type(enc)~='table' then return end
 for _,e in ipairs(enc) do
  local drops=call(h.GetSortedDropsForEncounter,e.encounterID)
  if type(drops)=='table' then for _,d in ipairs(drops) do
   if d.lootListKey~=nil then
    local key=tostring(e.encounterID)..':'..tostring(d.lootListKey)
    local full=call(h.GetSortedInfoForDrop,e.encounterID,d.lootListKey) or d
    local sig={tostring(full.winner and full.winner.playerName),tostring(full.allPassed)}
    for _,p in ipairs(full.rollInfos or {}) do sig[#sig+1]=table.concat({tostring(p.playerName),tostring(p.state),tostring(p.roll)},':') end
    sig=table.concat(sig,';')
    local r=records[key]; if not r then r={open=true}; records[key]=r; order[#order+1]=key end
    if r.sig~=sig then r.open=true; r.sig=sig end; r.data=full
    if full.winner and not seen[key] then
     seen[key]=true
     if initialized and db.announce and full.winner.playerName then
      local channel=IsInRaid() and 'RAID' or IsInGroup() and 'PARTY'; if channel then call(SendChatMessage,full.winner.playerName..' won '..(full.itemHyperlink or 'an item'),channel) end
     end
    end
   end
  end end
 end
 initialized=true; render()
end
local function manualRoll(msg)
 local n,v,l,h=msg:match('^(.+) rolls (%d+) %((%d+)%s*%-%s*(%d+)%)%.?$'); if not n then return end
 manual[#manual+1]=n..'   '..v..' ('..l..'-'..h..')'; if #manual>300 then table.remove(manual,1) end
 if panel then panel.manualOpen=true end; render()
end
f:SetScript('OnEvent',function(_,event,a)
 if event=='PLAYER_LOGIN' then RollsDB=RollsDB or {}; db=RollsDB; if db.announce==nil then db.announce=true end; if db.auto==nil then db.auto=true end; update(); say('Loaded. /rolls opens native window; /rolls details lists players.')
 elseif not db then return
 elseif event=='CHAT_MSG_SYSTEM' then if db.debug then log(event..' '..tostring(a)) end;manualRoll(a or '');parseLoot(a,event)
 elseif event=='CHAT_MSG_LOOT' then if db.debug then log(event..' '..tostring(a)) end;parseLoot(a,event)
 elseif event=='START_LOOT_ROLL' then
  local rollID=a
  local link=GetLootRollItemLink and call(GetLootRollItemLink,rollID)
  if link then ensureLive(link,'native:'..tostring(rollID)..':'..tostring(GetTime()));render() end
  log('START_LOOT_ROLL id='..tostring(rollID)..' link='..tostring(link));update()
 elseif event=='CANCEL_LOOT_ROLL' then log('CANCEL_LOOT_ROLL '..tostring(a));update()
 elseif event=='LOOT_HISTORY_CLEAR_HISTORY' then records={};order={};seen={};render()
 else log(event..' '..tostring(a)); update(); if db.auto and (event=='LOOT_HISTORY_GO_TO_ENCOUNTER' or event=='START_LOOT_ROLL') then openNative(event=='LOOT_HISTORY_GO_TO_ENCOUNTER' and a or nil) end end
end)
for _,ev in ipairs({'PLAYER_LOGIN','CHAT_MSG_SYSTEM','CHAT_MSG_LOOT','START_LOOT_ROLL','CANCEL_LOOT_ROLL','LOOT_HISTORY_GO_TO_ENCOUNTER','LOOT_HISTORY_UPDATE_ENCOUNTER','LOOT_HISTORY_UPDATE_DROP','LOOT_HISTORY_CLEAR_HISTORY'}) do local ok=pcall(f.RegisterEvent,f,ev); if not ok then log('Unsupported event '..ev) end end
local elapsed=0; f:SetScript('OnUpdate',function(_,dt) elapsed=elapsed+dt; if db and elapsed>=1 then elapsed=0; update() end end)
SLASH_ROLLS1='/rolls'; SlashCmdList.ROLLS=function(msg)
 msg=msg:lower():match('^%s*(.-)%s*$'); if not db then say('Waiting for login'); return end
 if msg=='details' or msg=='manual' then details()
 elseif msg=='announce' then db.announce=not db.announce; say('Announcements '..tostring(db.announce))
 elseif msg=='auto' then db.auto=not db.auto; say('Auto open '..tostring(db.auto))
 elseif msg=='status' then say('Native frame '..tostring(native()~=nil)..'; API '..tostring(C_LootHistory and type(C_LootHistory.GetSortedDropsForEncounter)=='function')..'; native items '..#order..'; live items '..#liveOrder..'; manual rolls '..#manual)
 elseif msg=='trace' then if #trace==0 then say('No captured messages yet.') end; for _,s in ipairs(trace) do say(s) end
 elseif msg=='debug' then db.debug=not db.debug;say('Debug '..tostring(db.debug))
 elseif msg=='help' then say('/rolls, /rolls details, /rolls manual, /rolls status, /rolls trace, /rolls debug, /rolls auto, /rolls announce')
 else local n=native(); if n and n:IsShown() then n:Hide() else openNative() end end
end
