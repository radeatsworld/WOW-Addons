Rolls v2.1.0 (experimental WoW Forever compatibility update)

Live group loot now listens for START_LOOT_ROLL and CHAT_MSG_LOOT / CHAT_MSG_SYSTEM in addition to native encounter history. Manual /roll results are separate.

Commands: /rolls, /rolls details, /rolls status, /rolls debug, /rolls trace, /rolls auto, /rolls announce

TEST: /rolls details; /rolls debug; perform a group loot roll; /rolls trace. If no live rows appear, copy the trace and chat loot messages. Server may not expose all per-player choices. This build has not been tested in the WoW Forever client.
