-- Titan Quest Count 1.0.1 - WoW Forever (16001)
local ADDON_ID = "QuestCount"
local LIMIT = 40
local function CountQuests()
    if C_QuestLog and C_QuestLog.GetNumQuestLogEntries then
        local entries, quests = C_QuestLog.GetNumQuestLogEntries()
        if type(quests) == "number" then return quests end
        local n = 0
        for i = 1, (entries or 0) do
            local info = C_QuestLog.GetInfo and C_QuestLog.GetInfo(i)
            if info and not info.isHeader then n = n + 1 end
        end
        return n
    end
    if GetNumQuestLogEntries and GetQuestLogTitle then
        local n = 0
        for i = 1, (GetNumQuestLogEntries() or 0) do
            local _, _, _, _, isHeader = GetQuestLogTitle(i)
            if not isHeader then n = n + 1 end
        end
        return n
    end
    return 0
end
function TitanPanelQuestCountButton_GetButtonText()
    return "Quests: ", tostring(CountQuests()) .. "/" .. LIMIT
end
function TitanPanelQuestCountButton_GetTooltipText()
    local count = CountQuests()
    return "Active quests: " .. count .. "/" .. LIMIT .. "\nAvailable slots: " .. math.max(0, LIMIT - count)
end
local button = CreateFrame("Button", "TitanPanelQuestCountButton", UIParent, "TitanPanelComboTemplate")
button.registry = {
    id = ADDON_ID,
    menuText = "Quest Count",
    buttonTextFunction = "TitanPanelQuestCountButton_GetButtonText",
    tooltipTitle = "Quest Count",
    tooltipTextFunction = "TitanPanelQuestCountButton_GetTooltipText",
    category = "Information",
    version = "1.0.1",
    icon = "Interface\\GossipFrame\\AvailableQuestIcon",
    iconWidth = 16,
    savedVariables = { ShowIcon = 1, ShowLabelText = 1, ShowColoredText = 1 },
}
local function Refresh()
    if TitanPanelButton_UpdateButton then TitanPanelButton_UpdateButton(ADDON_ID) end
end
button:RegisterEvent("PLAYER_ENTERING_WORLD")
button:RegisterEvent("QUEST_LOG_UPDATE")
button:RegisterEvent("QUEST_ACCEPTED")
button:RegisterEvent("QUEST_REMOVED")
button:RegisterEvent("QUEST_TURNED_IN")
button:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_ENTERING_WORLD" and C_Timer and C_Timer.After then
        C_Timer.After(1, Refresh)
    end
    Refresh()
end)
SLASH_TITANQUESTCOUNT1 = "/tqc"
SlashCmdList.TITANQUESTCOUNT = function()
    print("Titan Quest Count: " .. CountQuests() .. "/" .. LIMIT)
end
