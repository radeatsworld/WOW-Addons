HERMES_THALASSIAN = {
	LanguageID = 10,
	ALPHABET = {
        { "FAL", "ᾚₒὦ" },
        { "BAN", "ᾇẕẈ" },
        { "DAT", "﨩" },
        { "IS", "ࣸҀ" },
        { "MA", "᪉ႍ" },
        { "DO", "ᴸᖵ" },
        { "BE", "ខᢥ" },
        { "AM", "רɮ" },
        { "TH", "ͳʹ" },
		{ "A", "P" },
		{ "D", "𐍽" },
		{ "E", "D" },
		{ "F", "ᚡ" },
		{ "I", "4" },
        { "L", "ʀ" },
		{ "M", "👬" },
		{ "N", "Ǭ" },
		{ "O", "" },
		{ "R", "Ǫ" },
		{ "S", "ʀ" },
		{ "T", "༫" },
	},

	SUBSTITUTES = {
		B = 'D',
        C = 'S',
		G = 'F',
        H = 'TH',
        J = 'L',
		K = 'E',
		P = 'R',
		Q = 'DO',
		V = 'N',
        W = 'M',
		Y = 'F',
		Z = 'E'
	},

	SEPARATOR = {
		INPUT = 'p',
		OUTPUT = 'e'
	}
}
