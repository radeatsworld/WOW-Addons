-- Hermes Forever 1.3.0 - legacy Lua 5.1 compatible
local prefix = '|cff9bc6ffHermes|r: '
local function notice(s)
  if DEFAULT_CHAT_FRAME then DEFAULT_CHAT_FRAME:AddMessage(prefix .. tostring(s)) end
end
local function dictionary()
  local race, raceToken = UnitRace('player')
  local faction = UnitFactionGroup('player')
  if faction == 'Alliance' then return HERMES_COMMON, 'Common' end
  if raceToken == 'Scourge' or race == 'Undead' or race == 'Forsaken' then return HERMES_UNDEAD, 'Gutterspeak' end
  if raceToken == 'Troll' then return HERMES_ZANDALI, 'Zandali' end
  if raceToken == 'Tauren' then return HERMES_TAURAHE, 'Taurahe' end
  if raceToken == 'BloodElf' or race == 'Blood Elf' then return HERMES_THALASSIAN, 'Thalassian' end
  if faction == 'Horde' then return HERMES_ORCISH, 'Orcish' end
  return nil, nil
end
local function translate(message, dict)
  local input = string.upper(message or '')
  local outgoing, expected = {}, {}
  local alpha = dict.ALPHABET or {}
  local subs = dict.SUBSTITUTES or {}
  local sep = dict.SEPARATOR or {INPUT=' ', OUTPUT=' '}
  local steps = 0
  while #input > 0 and steps < 4096 do
    steps = steps + 1
    local matched = false
    for _, pair in ipairs(alpha) do
      local k, v = pair[1], pair[2]
      if string.sub(input, 1, #k) == k then
        table.insert(outgoing, v)
        table.insert(expected, k)
        input = string.sub(input, #k + 1)
        matched = true
        break
      end
    end
    if not matched then
      local ch = string.sub(input, 1, 1)
      local replacement = subs[ch]
      if replacement then
        input = replacement .. string.sub(input, 2)
        matched = true
      elseif string.find(ch, '%s') then
        table.insert(outgoing, sep.INPUT)
        table.insert(expected, sep.OUTPUT)
        input = string.sub(input, 2)
        matched = true
      end
    end
    if not matched then input = string.sub(input, 2) end
  end
  return table.concat(outgoing, ' '), table.concat(expected, ' ')
end
local function send(message, channel)
  if not message or not string.find(message, '%S') then
    notice('Usage: /hermes message, /yhermes message, /hermespreview message, /hermeshelp')
    return
  end
  local dict, language = dictionary()
  if not dict then notice('Unable to identify a supported character language.'); return end
  local encoded, preview = translate(message, dict)
  if encoded == '' then notice('No translatable letters found.'); return end
  -- Legacy chat clients and private servers may impose different message limits.
  if #encoded > 210 then notice('Encoded message is too long (' .. #encoded .. ' bytes; limit 210).'); return end
  notice('Language: ' .. language .. ' | Intended reading: ' .. preview)
  if channel == 'PREVIEW' then return end
  local fn = SendChatMessage
  if not fn and C_ChatInfo then fn = C_ChatInfo.SendChatMessage end
  if not fn then notice('Chat sending API unavailable.'); return end
  local ok, err = pcall(fn, encoded, channel, dict.LanguageID)
  if not ok then notice('Chat send failed: ' .. tostring(err)) end
end
SLASH_HERMES1 = '/hermes'
SLASH_HERMES2 = '/common'
SLASH_HERMES3 = '/orcish'
SLASH_HERMES4 = '/crossfaction'
SLASH_HERMES5 = '/cf'
SlashCmdList['HERMES'] = function(msg) send(msg, 'SAY') end
SLASH_YHERMES1 = '/yhermes'
SLASH_YHERMES2 = '/ycommon'
SLASH_YHERMES3 = '/yorcish'
SLASH_YHERMES4 = '/ycrossfaction'
SLASH_YHERMES5 = '/ycf'
SlashCmdList['YHERMES'] = function(msg) send(msg, 'YELL') end
SLASH_HERMESPREVIEW1 = '/hermespreview'
SLASH_HERMESPREVIEW2 = '/cfpreview'
SlashCmdList['HERMESPREVIEW'] = function(msg) send(msg, 'PREVIEW') end
SLASH_HERMESHELP1 = '/hermeshelp'
SlashCmdList['HERMESHELP'] = function()
  notice('/hermes <message> - Say | /yhermes <message> - Yell | /hermespreview <message> - Preview only')
  notice('Aliases: /common, /orcish, /cf, /ycf. Server language restrictions still apply.')
end
