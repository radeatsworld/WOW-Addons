HERMES_ZANDALI = {
	LanguageID = 14,
	ALPHABET = {
		{ "A", "A" },
		{ "C", "👭" },
		{ "D", "ᚤ" },
		{ "E", "B" },
		{ "F", "F" },
		{ "H", "H" },
		{ "I", "🐪" },
		{ "J", "F" },
		{ "M", "A" },
		{ "N", "ᚨ" },
		{ "O", "D" },
		{ "R", "😀" },
		{ "S", "V" },
		{ "T", "👬" },
		{ "U", "E" },
		{ "W", "ᚢ" },
		{ "Y", "𖣐" },
	},

	SUBSTITUTES = {
		B = 'F',
		G = 'J',
		K = 'C',
		L = 'S',
		P = 'R',
		Q = 'C',
		V = 'W',
		X = 'W',
		Z = 'W'
	},

	SEPARATOR = {
		INPUT = 'u',
		OUTPUT = 'e'
	}
}
