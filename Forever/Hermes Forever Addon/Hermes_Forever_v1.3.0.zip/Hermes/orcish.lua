HERMES_ORCISH = {
	LanguageID = 1,
	ALPHABET =  {
    { 'MU', 'AZ' },
    { 'IL', '44' },
		{ 'A', '1' },
		{ 'D', '🷙' },
		{ 'G', 'A' },
		{ 'H', 'Ɣ' },
		{ 'I', 'Ȋ' },
		{ 'K', 'ཎ' },
		{ 'L', 'D' },
		{ 'M', 'ா' },
		{ 'N', 'J' },
		{ 'O', 'C' },
		{ 'R', '' },
		{ 'T', 'ධ' },
		{ 'U', '🝥' },
		{ 'Z', 'ড়' }
	},
    
	SUBSTITUTES = {
		B = 'H',
		C = 'K',
		E = 'I',
		F = 'H',
		J = 'G',
		P = 'H',
		Q = 'K',
		S = 'Z',
		X = 'K',
		V = 'T',
		W = 'H',
		Y = 'I',
	},

	SEPARATOR = { 
		INPUT = 'x',
		OUTPUT = 'n'
	}
}