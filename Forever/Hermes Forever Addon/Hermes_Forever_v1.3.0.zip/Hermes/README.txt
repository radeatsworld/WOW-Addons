Hermes Forever 1.3.0

Install: Extract the Hermes folder to Interface\AddOns\Hermes. Restart WoW.

/hermes hello = Say
/yhermes hello = Yell
/hermespreview hello = preview only
/hermeshelp = commands
Aliases: /common /orcish /cf /ycommon /yorcish /ycf

This uses the supplied original dictionaries. Actual opposite-faction readability is dependent on WoW Forever server language rules and allowed character encoding. Test with another player. The chat client may reject Unicode glyphs from the original dictionaries; the addon cannot bypass server filtering.
